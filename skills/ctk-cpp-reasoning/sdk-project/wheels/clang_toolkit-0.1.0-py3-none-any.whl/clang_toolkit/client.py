"""Async and synchronous gRPC clients for clang-toolkit query services."""

from __future__ import annotations
from clang_toolkit._generated.analysis.v1 import script_response_pb2
from clang_toolkit.scripting import script_request

import asyncio
import concurrent.futures
from contextlib import aclosing
import inspect
import json
import uuid
import weakref
from threading import Lock
from collections.abc import AsyncIterator, Awaitable, Callable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Protocol, cast, overload

import grpc
from google.protobuf.message import DecodeError

from clang_toolkit._generated.query.v1 import query_pb2, query_pb2_grpc
from clang_toolkit._generated.index.v1 import index_service_pb2 as index_pb
from clang_toolkit._generated.index.v1 import index_service_pb2_grpc as index_grpc
from clang_toolkit.configuration import NetworkConfig, load_network_config
from clang_toolkit.version import VersionInfo
from clang_toolkit.cursors import CursorError, file_request, retained_request
from clang_toolkit._generated.match.v1 import match_service_pb2, match_service_pb2_grpc
from clang_toolkit._generated.match.v1 import match_result_pb2
from clang_toolkit._generated.match.v1 import match_stream_pb2
from clang_toolkit._generated.match.v1 import resources_pb2
from clang_toolkit._generated.analysis.v1 import analysis_service_pb2_grpc, traverse_response_pb2, cfg_response_pb2, call_graph_response_pb2, call_graph_request_pb2, call_graph_stream_pb2
from clang_toolkit._generated.analysis.v1 import traverse_stream_pb2, traverse_request_pb2
from clang_toolkit._generated.analysis.v1 import cfg_stream_pb2, cfg_request_pb2
from clang_toolkit.cfg_stream import CfgStreamState
from clang_toolkit.call_graph_stream import CallGraphStreamState
from clang_toolkit.call_graph_values import CallGraph, CallGraphNodeValue
from clang_toolkit.variable_flow import VariableFlowState
from clang_toolkit._generated.analysis.v1 import variable_flow_pb2
from clang_toolkit._generated.analysis.v1 import batch_pb2
from clang_toolkit.batches import BatchRun, batch_run, start_batch_request
from clang_toolkit.analysis_error import AnalysisError
from clang_toolkit.traversal import traversal_request
from clang_toolkit.control_flow import CfgOptions, cfg_request
from clang_toolkit.call_graph import call_graph_request
from clang_toolkit.match_values import (
    BindingSelection, MatchTarget, MatchValue, MatchValueError, ParsedTree,
)
from clang_toolkit.matchers import MatcherInput, matcher_query
from clang_toolkit.resources import (
    FileHandle,
    FileSet,
    InputDescriptor,
    ResourceScope,
    _preserve_cleanup_error,
)
from clang_toolkit._value_lifecycle import CursorOwner, OperationLease
from clang_toolkit._row_store import RowStore
from clang_toolkit._generated.match.v1 import parse_request_pb2, parse_response_pb2

QueryEvent = query_pb2.QueryEvent
EventCallback = Callable[[QueryEvent], Any | Awaitable[Any]]
AsyncMatchRowCallback = Callable[[match_result_pb2.MatchResult], Any | Awaitable[Any]]
MatchRowCallback = Callable[[match_result_pb2.MatchResult], None]


async def _invoke_sync_callback(callback: MatchRowCallback,
                                row: match_result_pb2.MatchResult) -> None:
    """Run blocking row work outside the RPC loop and join it on cancellation."""
    def invoke() -> None:
        outcome = callback(row)
        if inspect.isawaitable(outcome):
            if inspect.iscoroutine(outcome):
                outcome.close()
            raise TypeError("synchronous on_row callbacks must not return awaitables")

    worker = asyncio.create_task(asyncio.to_thread(invoke))
    try:
        await asyncio.shield(worker)
    except asyncio.CancelledError:
        await asyncio.gather(worker, return_exceptions=True)
        raise


class _MatchStreamCall(Protocol):
    def __aiter__(self) -> AsyncIterator[match_stream_pb2.MatchStreamEvent]: ...

    def code(self) -> grpc.StatusCode | Awaitable[grpc.StatusCode]: ...

    def details(self) -> str | Awaitable[str]: ...

    def cancel(self) -> bool: ...


class _MatchStreamStub(Protocol):
    def StreamMatch(
        self, request: match_service_pb2.MatchRequest, *, timeout: float | None = None,
    ) -> _MatchStreamCall: ...


class QueryError(RuntimeError):
    """Query failed after zero or more partial events had been received."""

    def __init__(
        self,
        message: str,
        *,
        partial_events: Sequence[QueryEvent] = (),
        rejected: query_pb2.Rejected | None = None,
    ) -> None:
        self.partial_events = tuple(partial_events)
        self.rejected = rejected
        self.violations = tuple(rejected.violations) if rejected is not None else ()
        if self.violations:
            message = f"{message}; " + "; ".join(
                _format_violation(item) for item in self.violations
            )
        super().__init__(message)


def _rejection_from_status(error: grpc.aio.AioRpcError) -> query_pb2.Rejected | None:
    for key, value in error.trailing_metadata() or ():
        if key == "grpc-status-details-bin":
            rejected = query_pb2.Rejected()
            try:
                rejected.ParseFromString(value)
            except DecodeError:
                return None
            return rejected
    return None


def _format_violation(violation: query_pb2.LimitViolation) -> str:
    text = (
        f"{violation.limit_name}: current {violation.current_value}, "
        f"requested +{violation.requested_increment}, projected {violation.projected_value}, "
        f"limit {violation.configured_limit}"
    )
    if "memory" in violation.limit_name:
        text += (
            f"; current {violation.current_value / (1024 ** 3):.2f} GiB"
            f"; requested {violation.requested_increment / (1024 ** 3):.2f} GiB"
            f"; projected {violation.projected_value / (1024 ** 3):.2f} GiB"
            f"; limit {violation.configured_limit / (1024 ** 3):.2f} GiB"
        )
    return text


def _file_inputs(
    files: Sequence[str | Path], *, working_directory: str | Path | None = None,
    compile_arguments: Sequence[str] = (),
) -> list[query_pb2.FileInput]:
    working = str(Path(working_directory or Path.cwd()).resolve())
    base = Path(working)
    return [
        query_pb2.FileInput(
            path=str((Path(path).expanduser() if Path(path).expanduser().is_absolute() else base / Path(path).expanduser()).resolve()),
            compile_arguments=compile_arguments,
            working_directory=working,
        )
        for path in files
    ]


@dataclass
class AsyncClient:
    """Loop-owned ``grpc.aio`` client with collecting and streaming APIs."""

    address: str | None = None
    config_path: str | Path | None = None
    config: NetworkConfig | None = None
    compilation_database: str | Path | None = None
    _channel: grpc.aio.Channel | None = field(default=None, init=False, repr=False)
    _stub: query_pb2_grpc.QueryServiceStub | None = field(default=None, init=False, repr=False)
    _loop: asyncio.AbstractEventLoop | None = field(default=None, init=False, repr=False)
    _background: set[asyncio.Task[list[QueryEvent]]] = field(
        default_factory=set, init=False, repr=False
    )
    _values: dict[str, weakref.ReferenceType[CursorOwner[AsyncClient]]] = field(
        default_factory=dict, init=False, repr=False)
    _value_cleanup: set[asyncio.Task[None]] = field(
        default_factory=set, init=False, repr=False)
    _value_cleanup_by_id: dict[str, asyncio.Task[None]] = field(
        default_factory=dict, init=False, repr=False)
    _pending_value_cleanup: set[str] = field(default_factory=set, init=False, repr=False)
    _file_leases: set[str] = field(default_factory=set, init=False, repr=False)
    _resource_scopes: dict[str, ResourceScope[AsyncClient]] = field(default_factory=dict, init=False, repr=False)
    _expression_runtime: Any = field(default=None, init=False, repr=False)
    _expression_lock: asyncio.Lock | None = field(default=None, init=False, repr=False)
    _value_closing: bool = field(default=False, init=False, repr=False)
    _value_closed: bool = field(default=False, init=False, repr=False)
    _value_operation_count: int = field(default=0, init=False, repr=False)
    _value_idle: asyncio.Event | None = field(default=None, init=False, repr=False)
    _value_close_lock: asyncio.Lock | None = field(default=None, init=False, repr=False)

    def _compilation_request(self, request: Any) -> Any:
        """Select a server-side database for every file/profile RPC."""
        selected = str(self.compilation_database or "")
        if not selected:
            return request
        if (hasattr(request, "compilation_database") and not request.compilation_database
                and not getattr(request, "frozen_profile", False)):
            request.compilation_database = selected
        if hasattr(request, "file") and request.HasField("file"):
            if not request.file.compilation_database and not getattr(request.file, "frozen_profile", False):
                request.file.compilation_database = selected
        if hasattr(request, "profile") and request.HasField("profile"):
            if (not request.profile.compilation_database
                    and not getattr(request.profile, "frozen", False)):
                request.profile.compilation_database = selected
        if hasattr(request, "input") and request.HasField("input"):
            if (not request.input.profile.compilation_database
                    and not request.input.profile.frozen):
                request.input.profile.compilation_database = selected
        for input_descriptor in getattr(request, "inputs", ()):
            if (not input_descriptor.profile.compilation_database
                    and not input_descriptor.profile.frozen):
                input_descriptor.profile.compilation_database = selected
        for file in getattr(request, "files", ()):
            if not file.compilation_database:
                file.compilation_database = selected
        return request

    def _ensure_stub(self) -> query_pb2_grpc.QueryServiceStub:
        loop = asyncio.get_running_loop()
        if self._loop is not None and self._loop is not loop:
            raise RuntimeError("AsyncClient must be used from the event loop that created it")
        if self._stub is None:
            self.config = (load_network_config(self.config_path)
                           if self.config_path is not None else
                           self.config or load_network_config())
            self._loop = loop
            target = self.address or self.config.target
            self._channel = grpc.aio.insecure_channel(target, options=self.config.client_options)
            self._stub = query_pb2_grpc.QueryServiceStub(self._channel)
        return self._stub

    async def server_version(self) -> VersionInfo:
        """Return the connected server binary's build identity."""
        stub = self._ensure_stub()
        assert self.config is not None
        try:
            response = await stub.GetVersion(query_pb2.VersionRequest(), timeout=self.config.rpc_timeout or 5.0)
        except grpc.aio.AioRpcError as error:
            if error.code() == grpc.StatusCode.UNIMPLEMENTED:
                raise QueryError("connected server does not support version reporting; update and restart it") from error
            raise QueryError(f"server version request failed: {error.code().name}: {error.details()}") from error
        return VersionInfo(response.version, response.revision)

    async def _resource_call(self, method: str, request: Any) -> Any:
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        stub = match_service_pb2_grpc.MatchServiceStub(self._channel)
        try:
            return await getattr(stub, method)(
                self._compilation_request(request), timeout=self.config.rpc_timeout
            )
        except grpc.aio.AioRpcError as error:
            raise CursorError(error.code(), error.details()) from error

    async def discover_files(
        self,
        paths: Sequence[str | Path] = (),
        *,
        inputs: Sequence[InputDescriptor] = (),
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        compilation_database: str | Path | None = None,
        max_inputs: int | None = None,
        max_metadata_bytes: int | None = None,
    ) -> FileSet:
        """Discover server-side paths as frozen metadata without parsing ASTs."""
        if paths and inputs:
            raise ValueError("provide paths or inputs, not both")
        profile = resources_pb2.CompilationProfile(
            compile_arguments=compile_arguments,
            working_directory=str(working_directory) if working_directory is not None else str(Path.cwd()),
            compilation_database=str(compilation_database or self.compilation_database or ""),
        )
        request = resources_pb2.DiscoverFilesRequest(
            paths=[str(path) for path in paths],
            profile=profile,
            inputs=[item.to_proto() for item in inputs],
        )
        if max_inputs is not None:
            request.max_inputs = max_inputs
        if max_metadata_bytes is not None:
            request.max_metadata_bytes = max_metadata_bytes
        response = await self._resource_call("DiscoverFiles", request)
        return FileSet(
            tuple(InputDescriptor.from_proto(item) for item in response.inputs),
            tuple(response.diagnostics),
            response.metadata_bytes,
        )

    async def open_file(
        self,
        value: str | Path | InputDescriptor,
        *,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        compilation_database: str | Path | None = None,
        scope: ResourceScope[AsyncClient] | str | None = None,
    ) -> FileHandle[AsyncClient]:
        descriptor = value if isinstance(value, InputDescriptor) else InputDescriptor.from_path(
            value, working_directory=working_directory, compile_arguments=compile_arguments,
            compilation_database=compilation_database or self.compilation_database,
        )
        request = resources_pb2.OpenFileRequest(
            input=descriptor.to_proto(), resource_scope_id=_scope_id(scope)
        )
        info = await self._resource_call("OpenFile", request)
        handle = _file_handle(self, info)
        if scope is None:
            self._file_leases.add(handle.lease_id)
        return handle

    async def list_files(self) -> tuple[Any, ...]:
        response = await self._resource_call("ListFiles", resources_pb2.ListFilesRequest())
        return tuple(response.files)

    async def file_info(self, handle: FileHandle[AsyncClient] | ParsedTree[AsyncClient]) -> Any:
        request = resources_pb2.DescribeFileRequest()
        if isinstance(handle, FileHandle):
            request.lease_id = handle.lease_id
        else:
            request.session_id = handle._owner.session_id
        return await self._resource_call("DescribeFile", request)

    async def close_file(
        self, handle: FileHandle[AsyncClient] | ParsedTree[AsyncClient] | str,
    ) -> Any:
        request = resources_pb2.CloseFileRequest()
        if isinstance(handle, FileHandle):
            request.lease_id = handle.lease_id
        elif isinstance(handle, str):
            request.lease_id = handle
        else:
            request.session_id = handle._owner.session_id
        try:
            response = await self._resource_call("CloseFile", request)
        except CursorError as error:
            if (
                request.WhichOneof("handle") != "lease_id"
                or error.code != grpc.StatusCode.NOT_FOUND
            ):
                raise
            # Closing a lease is idempotent. NOT_FOUND means it was already
            # released or expired; it must not remain in shutdown tracking.
            response = resources_pb2.CloseFileResponse()
        if request.WhichOneof("handle") == "lease_id":
            self._file_leases.discard(request.lease_id)
        return response

    async def close_all_files(self) -> Any:
        response = await self._resource_call("CloseAllFiles", resources_pb2.CloseAllFilesRequest())
        self._file_leases.clear()
        return response

    async def refresh_file(
        self,
        handle: FileHandle[AsyncClient] | ParsedTree[AsyncClient],
        *,
        scope: ResourceScope[AsyncClient] | str | None = None,
    ) -> FileHandle[AsyncClient]:
        request = resources_pb2.RefreshFileRequest(resource_scope_id=_scope_id(scope))
        if isinstance(handle, FileHandle):
            request.lease_id = handle.lease_id
        else:
            request.session_id = handle._owner.session_id
        refreshed = _file_handle(self, await self._resource_call("RefreshFile", request))
        if scope is None:
            self._file_leases.add(refreshed.lease_id)
        return refreshed

    async def open_resource_scope(
        self,
        *,
        inputs: Sequence[InputDescriptor] = (),
        memory_bytes: int | None = None,
        jobs: int | None = None,
        transient: bool = False,
        ttl_ms: int | None = None,
    ) -> ResourceScope[AsyncClient]:
        request = resources_pb2.OpenResourceScopeRequest(
            inputs=[item.to_proto() for item in inputs], transient=transient
        )
        if memory_bytes is not None:
            request.memory_bytes = memory_bytes
        if jobs is not None:
            request.jobs = jobs
        if ttl_ms is not None:
            request.ttl_ms = ttl_ms
        info = await self._resource_call("OpenResourceScope", request)
        if not info.resource_scope_id:
            raise CursorError(grpc.StatusCode.DATA_LOSS, "resource scope reply has no scope ID")
        scope = ResourceScope(info.resource_scope_id, info, self)
        self._resource_scopes[scope.resource_scope_id] = scope
        return scope

    async def describe_resource_scope(
        self, scope: ResourceScope[AsyncClient] | str,
    ) -> Any:
        return await self._resource_call(
            "DescribeResourceScope",
            resources_pb2.ResourceScopeRequest(resource_scope_id=_scope_id(scope)),
        )

    async def cancel_resource_scope(
        self, scope: ResourceScope[AsyncClient] | str,
    ) -> Any:
        return await self._resource_call(
            "CancelResourceScope",
            resources_pb2.ResourceScopeRequest(resource_scope_id=_scope_id(scope)),
        )

    async def release_resource_scope(
        self, scope: ResourceScope[AsyncClient] | str,
    ) -> Any:
        info = await self._resource_call(
            "ReleaseResourceScope",
            resources_pb2.ResourceScopeRequest(resource_scope_id=_scope_id(scope)),
        )
        if info.cleanup_acknowledged:
            self._resource_scopes.pop(_scope_id(scope), None)
        return info

    async def resource_status(self) -> Any:
        return await self._resource_call(
            "ResourceStatus", resources_pb2.ResourceStatusRequest()
        )

    async def iter_events(
        self,
        query: MatcherInput,
        files: Sequence[str | Path] = (),
        *,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
    ) -> AsyncIterator[QueryEvent]:
        """Yield events, requiring both a Completed event and terminal OK."""
        stub = self._ensure_stub()
        assert self.config is not None
        request = query_pb2.QueryRequest(
            query=matcher_query(query),
            files=_file_inputs(
                files, working_directory=working_directory,
                compile_arguments=compile_arguments,
            ),
        )
        call = stub.Query(self._compilation_request(request), timeout=self.config.rpc_timeout)
        received: list[QueryEvent] = []
        completed = False
        consumed = False
        rejected_event: query_pb2.Rejected | None = None
        try:
            async for event in call:
                received.append(event)
                if event.WhichOneof("event") == "completed":
                    completed = True
                if event.WhichOneof("event") == "rejected":
                    rejected_event = event.rejected
                yield event
            if not completed:
                raise QueryError("query stream ended without Completed", partial_events=received)
            if rejected_event is not None:
                raise QueryError(
                    f"query rejected ({rejected_event.code}): {rejected_event.message}",
                    partial_events=received,
                    rejected=rejected_event,
                )
            consumed = True
        except grpc.aio.AioRpcError as exc:
            raise QueryError(
                f"query RPC failed: {exc.code().name}: {exc.details()}",
                partial_events=received,
                rejected=_rejection_from_status(exc) or rejected_event,
            ) from exc
        except asyncio.CancelledError as exc:
            if asyncio.current_task() and asyncio.current_task().cancelling():
                raise
            raise QueryError("query RPC cancelled: CANCELLED", partial_events=received) from exc
        finally:
            if not consumed and not call.done():
                call.cancel()

    async def query(
        self,
        expression: MatcherInput,
        files: Sequence[str | Path] = (),
        *,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        on_event: EventCallback | None = None,
    ) -> list[QueryEvent]:
        """Collect an entire successful query stream or raise with partials."""
        events: list[QueryEvent] = []
        stream = self.iter_events(
            expression, files, working_directory=working_directory,
            compile_arguments=compile_arguments,
        )
        async with aclosing(stream):
            async for event in stream:
                events.append(event)
                if on_event is not None:
                    outcome = on_event(event)
                    if inspect.isawaitable(outcome):
                        await outcome
        return events

    @overload
    async def match(
        self, expression: MatcherInput, files: Sequence[str | Path] = (), *,
        file: str | Path, working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
    ) -> MatchValue[AsyncClient]: ...

    @overload
    async def match(
        self, expression: MatcherInput, files: Sequence[str | Path] = (), *,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (), file: None = None,
    ) -> list[query_pb2.MatchEvent]: ...

    async def match(
        self,
        expression: MatcherInput,
        files: Sequence[str | Path] = (),
        *,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        file: str | Path | None = None,
    ) -> list[query_pb2.MatchEvent] | MatchValue[AsyncClient]:
        """Collect typed match rows after successful terminal completion."""
        if file is not None:
            if files:
                raise ValueError("use either file or files, not both")
            return await self.match_in(expression, file,
                working_directory=working_directory, compile_arguments=compile_arguments)
        events = await self.query(
            expression, files, working_directory=working_directory,
            compile_arguments=compile_arguments,
        )
        return [event.match for event in events if event.WhichOneof("event") == "match"]

    async def _cursor_match(self, request: match_service_pb2.MatchRequest) -> match_service_pb2.MatchResponse:
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        stub = match_service_pb2_grpc.MatchServiceStub(self._channel)
        try:
            return await stub.Match(self._compilation_request(request), timeout=self.config.rpc_timeout)
        except grpc.aio.AioRpcError as error:
            raise CursorError(error.code(), error.details()) from error

    async def _stream_cursor_match(
        self,
        request: match_service_pb2.MatchRequest,
        *,
        on_row: AsyncMatchRowCallback | None = None,
        source_session_id: str | None = None,
    ) -> tuple[match_stream_pb2.MatchStreamCompleted, RowStore]:
        """Consume provisional rows and return them only after a valid terminal OK."""
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        stub = cast(
            _MatchStreamStub,
            match_service_pb2_grpc.MatchServiceStub(self._channel),
        )
        store = RowStore()
        call: _MatchStreamCall | None = None
        completed: match_stream_pb2.MatchStreamCompleted | None = None
        row_count = 0
        succeeded = False
        try:
            stream_method = (getattr(stub, "StreamNavigate")
                             if request.navigation_axis else stub.StreamMatch)
            call = stream_method(
                self._compilation_request(request), timeout=self.config.rpc_timeout
            )
            async for event in call:
                kind = event.WhichOneof("event")
                if kind == "row":
                    if completed is not None:
                        raise CursorError(grpc.StatusCode.DATA_LOSS,
                                          "match stream delivered a row after completion")
                    if request.navigation_axis and "target" not in event.row.bindings:
                        raise CursorError(grpc.StatusCode.DATA_LOSS,
                                          "navigation stream row is missing its target")
                    row_bytes = event.row.SerializeToString()
                    store.append(row_bytes, binding_names=event.row.bindings)
                    row_count += 1
                    if on_row is not None:
                        detached = match_result_pb2.MatchResult()
                        detached.ParseFromString(row_bytes)
                        outcome = on_row(detached)
                        if inspect.isawaitable(outcome):
                            await outcome
                elif kind == "completed":
                    if completed is not None:
                        raise CursorError(grpc.StatusCode.DATA_LOSS,
                                          "match stream delivered duplicate completion")
                    completed = match_stream_pb2.MatchStreamCompleted()
                    completed.CopyFrom(event.completed)
                    if (not completed.session_id or completed.result_revision <= 0
                            or completed.row_count < 0 or not completed.HasField("expires_at")):
                        raise CursorError(grpc.StatusCode.DATA_LOSS,
                                          "match stream completion metadata is invalid")
                    if completed.row_count != row_count:
                        raise CursorError(
                            grpc.StatusCode.DATA_LOSS,
                            f"match stream row count mismatch: expected {completed.row_count}, received {row_count}",
                        )
                else:
                    raise CursorError(grpc.StatusCode.DATA_LOSS,
                                      "match stream delivered an unknown event")

            if completed is None:
                raise CursorError(grpc.StatusCode.DATA_LOSS,
                                  "match stream ended without completion")
            assert call is not None
            status_result = call.code()
            status = await status_result if inspect.isawaitable(status_result) else status_result
            if status != grpc.StatusCode.OK:
                details_result = call.details()
                details = (await details_result if inspect.isawaitable(details_result)
                           else details_result)
                raise CursorError(status, details or "match stream did not finish with OK")
            store.flush()
            succeeded = True
            return completed, store
        except grpc.aio.AioRpcError as error:
            raise CursorError(error.code(), error.details() or "match stream RPC failed") from error
        finally:
            if not succeeded:
                if call is not None:
                    try:
                        call.cancel()
                    except BaseException:
                        pass
                try:
                    store.close()
                except BaseException:
                    pass
                if (completed is not None and completed.session_id
                        and completed.session_id != source_session_id):
                    try:
                        cleanup = asyncio.create_task(self.close_match(completed.session_id))
                        cleanup.add_done_callback(
                            lambda task: task.exception() if not task.cancelled() else None
                        )
                        await asyncio.shield(cleanup)
                    except BaseException:
                        # Cleanup is best effort; preserve the original stream failure.
                        pass

    async def _parse_response(
        self, path: str | Path | InputDescriptor, *, working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (), compilation_database: str | Path | None = None,
        scope: ResourceScope[AsyncClient] | str | None = None,
    ) -> parse_response_pb2.ParseResponse:
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        descriptor = path if isinstance(path, InputDescriptor) else None
        source_path = descriptor.path if descriptor is not None else str(path)
        request = parse_request_pb2.ParseRequest(
            file_path=source_path,
            compile_arguments=(descriptor.compile_arguments if descriptor else compile_arguments),
            compilation_database=(descriptor.compilation_database if descriptor else
                                  str(compilation_database or "")),
            working_directory=(descriptor.working_directory if descriptor and descriptor.working_directory else
                               str(working_directory) if working_directory is not None else str(Path.cwd())),
            resource_scope_id=_scope_id(scope),
        )
        if descriptor is not None and descriptor.profile_id:
            request.expected_profile_id = descriptor.profile_id
        if descriptor is not None:
            request.frozen_profile = descriptor.frozen_profile
        try:
            return await match_service_pb2_grpc.MatchServiceStub(self._channel).Parse(
                self._compilation_request(request), timeout=self.config.rpc_timeout)
        except grpc.aio.AioRpcError as error:
            raise CursorError(error.code(), error.details()) from error

    async def _parse_cpp_response(
        self, code: str, *, file: str | Path | None = None,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        compilation_database: str | Path | None = None,
        includes: Sequence[str] = (), translation_unit: bool = False,
        scope: ResourceScope[AsyncClient] | str | None = None,
    ) -> parse_response_pb2.ParseResponse:
        request = parse_request_pb2.ParseRequest(
            compile_arguments=compile_arguments,
            compilation_database=str(compilation_database or ""),
            working_directory=str(working_directory) if working_directory is not None else str(Path.cwd()),
            resource_scope_id=_scope_id(scope),
            cpp_snippet=parse_request_pb2.CppSnippet(
                code=code, settings_file=str(file or ""), includes=includes,
                translation_unit=translation_unit,
            ),
        )
        return await self._resource_call("Parse", request)

    def _own_value(self, response: Any) -> CursorOwner[AsyncClient]:
        current = self._values.get(response.session_id)
        existing = current() if current else None
        if existing is not None and not existing.closed and existing.revision == response.result_revision:
            return existing
        holder: list[Any] = [None]
        def release(session_id: str) -> None:
            if self._values.get(session_id) is holder[0]:
                self._release_value(session_id)
        owner = CursorOwner(cast(AsyncClient, self), response.session_id, response.result_revision,
                             release, loop=asyncio.get_running_loop())
        holder[0] = self._values[response.session_id] = weakref.ref(owner)
        return owner

    def _release_value(self, session_id: str) -> None:
        loop = self._loop
        def release_on_loop() -> None:
            self._pending_value_cleanup.add(session_id)
            self._values.pop(session_id, None)
            self._schedule_value_cleanup(session_id)

        if loop is None:
            self._pending_value_cleanup.add(session_id)
            self._values.pop(session_id, None)
            return
        if loop.is_closed():
            self._pending_value_cleanup.add(session_id)
            self._values.pop(session_id, None)
            return
        try:
            running = asyncio.get_running_loop()
        except RuntimeError:
            running = None
        if running is loop:
            release_on_loop()
        else:
            loop.call_soon_threadsafe(release_on_loop)

    def _cleanup_task_done(self, identifier: str, task: asyncio.Task[None]) -> None:
        if self._value_cleanup_by_id.get(identifier) is task:
            self._value_cleanup_by_id.pop(identifier, None)
        self._value_cleanup.discard(task)
        if not task.cancelled():
            # Finalizer-triggered cleanup has no caller to observe a failure.
            # Retrieve it here and leave the identifier pending for retry.
            task.exception()

    def _schedule_value_cleanup(self, identifier: str) -> asyncio.Task[None]:
        task = self._value_cleanup_by_id.get(identifier)
        if task is None or task.done():
            task = asyncio.create_task(self._close_value_cleanup_once(identifier))
            self._value_cleanup_by_id[identifier] = task
            self._value_cleanup.add(task)
            task.add_done_callback(lambda done, key=identifier: self._cleanup_task_done(key, done))
        return task

    async def _close_value_cleanup(self, identifier: str) -> None:
        if identifier not in self._pending_value_cleanup:
            return
        task = self._schedule_value_cleanup(identifier)
        await asyncio.shield(task)

    async def _close_value_cleanup_once(self, identifier: str) -> None:
        await self.close_match(identifier)
        self._pending_value_cleanup.discard(identifier)

    async def _flush_value_cleanup(self) -> None:
        tasks = tuple(self._value_cleanup)
        if tasks:
            outcomes = await asyncio.gather(
                *(asyncio.shield(task) for task in tasks), return_exceptions=True
            )
            _raise_cleanup_errors([outcome for outcome in outcomes
                                   if isinstance(outcome, BaseException)])

    def _begin_value_operation(self, lease: OperationLease | None = None) -> None:
        accepted = lease is not None and lease.client is self and lease.active
        if (self._value_closing or self._value_closed) and not accepted:
            raise MatchValueError("client is closing or closed")
        self._ensure_stub()
        for identifier in tuple(self._pending_value_cleanup):
            if identifier not in self._value_cleanup_by_id:
                self._schedule_value_cleanup(identifier)
        if self._value_idle is None:
            self._value_idle = asyncio.Event()
        self._value_operation_count += 1
        self._value_idle.clear()

    def _end_value_operation(self) -> None:
        self._value_operation_count -= 1
        if self._value_operation_count == 0 and self._value_idle is not None:
            self._value_idle.set()

    async def parse(
        self, path: str | Path | InputDescriptor, *, working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (), compilation_database: str | Path | None = None,
        scope: ResourceScope[AsyncClient] | str | None = None,
    ) -> ParsedTree[AsyncClient]:
        """Parse a file once and retain a reusable immutable native tree."""
        return await self._parse_with_lease(path, working_directory=working_directory,
                                            compile_arguments=compile_arguments, compilation_database=compilation_database,
                                            lease=None, scope=scope)

    async def _parse_with_lease(
        self, path: str | Path | InputDescriptor, *, working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (), compilation_database: str | Path | None = None,
        lease: OperationLease | None, scope: ResourceScope[AsyncClient] | str | None = None,
    ) -> ParsedTree[AsyncClient]:
        self._begin_value_operation(lease)
        try:
            response = await self._parse_response(path, working_directory=working_directory,
                compile_arguments=compile_arguments, compilation_database=compilation_database,
                scope=scope)
            return ParsedTree(
                path.path if isinstance(path, InputDescriptor) else str(path), self._own_value(response),
                _absolute_source_file(path, working_directory),
            )
        finally:
            self._end_value_operation()

    async def parse_cpp(
        self, code: str, *, file: str | Path | None = None,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        compilation_database: str | Path | None = None,
        includes: Sequence[str] = (), translation_unit: bool = False,
        scope: ResourceScope[AsyncClient] | str | None = None,
    ) -> ParsedTree[AsyncClient]:
        """Parse temporary C++ statements, borrowing a file's compiler settings.

        Without ``file``, use the first available compilation database command.
        ``translation_unit=True`` accepts complete top-level C++ source instead.
        """
        return await self._parse_cpp_with_lease(
            code, file=file, working_directory=working_directory,
            compile_arguments=compile_arguments, compilation_database=compilation_database,
            includes=includes, translation_unit=translation_unit, scope=scope, lease=None,
        )

    async def _parse_cpp_with_lease(
        self, code: str, *, file: str | Path | None = None,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        compilation_database: str | Path | None = None,
        includes: Sequence[str] = (), translation_unit: bool = False,
        scope: ResourceScope[AsyncClient] | str | None = None,
        lease: OperationLease | None,
    ) -> ParsedTree[AsyncClient]:
        self._begin_value_operation(lease)
        try:
            response = await self._parse_cpp_response(
                code, file=file, working_directory=working_directory,
                compile_arguments=compile_arguments, compilation_database=compilation_database,
                includes=includes, translation_unit=translation_unit, scope=scope,
            )
            return ParsedTree(response.source_file, self._own_value(response), response.source_file)
        finally:
            self._end_value_operation()

    async def match_in(
        self, query: MatcherInput, target: MatchTarget | Path, *,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        traversal_mode: match_service_pb2.MatchTraversalMode = match_service_pb2.MATCH_TRAVERSAL_MODE_AS_IS,
        on_row: AsyncMatchRowCallback | None = None,
        scope: ResourceScope[AsyncClient] | str | None = None,
    ) -> MatchValue[AsyncClient]:
        """Match a path, pinned tree or binding selection without changing it."""
        return await self._match_in_with_lease(query, target,
            working_directory=working_directory, compile_arguments=compile_arguments,
            traversal_mode=traversal_mode, on_row=on_row, lease=None, scope=scope)

    async def _match_in_with_lease(
        self, query: MatcherInput, target: MatchTarget, *,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        traversal_mode: match_service_pb2.MatchTraversalMode = match_service_pb2.MATCH_TRAVERSAL_MODE_AS_IS,
        on_row: AsyncMatchRowCallback | None = None,
        lease: OperationLease | None, scope: ResourceScope[AsyncClient] | str | None = None,
    ) -> MatchValue[AsyncClient]:
        if isinstance(target, CallGraphNodeValue):
            target = target.binding
        self._begin_value_operation(lease)
        try:
            request = _value_request(self, query, target,
                working_directory=working_directory, compile_arguments=compile_arguments,
                traversal_mode=traversal_mode, scope=scope)
            source_id = target._owner.session_id if isinstance(
                target, (ParsedTree, MatchValue, BindingSelection)
            ) else None
            completion, store = await self._stream_cursor_match(
                request, on_row=on_row, source_session_id=source_id
            )
            return MatchValue[AsyncClient]._from_store(
                store, self._own_value(completion),
                source_file=_absolute_source_file(target, working_directory),
            )
        finally:
            self._end_value_operation()

    async def peek(self, target: BindingSelection, *, axis: str = "children",
                   query: MatcherInput | None = None, max_nodes: int = 0,
                   on_row: AsyncMatchRowCallback | None = None,
                   scope: ResourceScope[AsyncClient] | str | None = None
                   ) -> MatchValue[AsyncClient]:
        """Stream direct neighbours into an independent retained collection."""
        return await self._peek_with_lease(target, axis=axis, query=query,
            max_nodes=max_nodes, on_row=on_row, scope=scope, lease=None)

    async def _peek_with_lease(self, target: BindingSelection, *,
                              axis: str = "children",
                              query: MatcherInput | None = None,
                              max_nodes: int = 0,
                              on_row: AsyncMatchRowCallback | None = None,
                              scope: ResourceScope[AsyncClient] | str | None = None,
                              lease: OperationLease | None = None
                              ) -> MatchValue[AsyncClient]:
        self._begin_value_operation(lease)
        try:
            request = _navigation_request(self, target, axis, query, max_nodes, scope)
            completion, store = await self._stream_cursor_match(
                request, on_row=on_row, source_session_id=target._owner.session_id)
            return MatchValue._from_store(store, self._own_value(completion),
                                          source_file=target.source_file)
        finally:
            self._end_value_operation()

    async def step(self, target: BindingSelection, *, axis: str = "children",
                   query: MatcherInput | None = None, at: int | None = None,
                   max_nodes: int = 0,
                   scope: ResourceScope[AsyncClient] | str | None = None
                   ) -> BindingSelection[AsyncClient]:
        """Select one direct neighbour; reject absent or ambiguous selections."""
        return await self._step_with_lease(target, axis=axis, query=query,
            at=at, max_nodes=max_nodes, scope=scope)

    async def _step_with_lease(self, target: BindingSelection, *,
                              axis: str = "children",
                              query: MatcherInput | None = None,
                              at: int | None = None, max_nodes: int = 0,
                              scope: ResourceScope[AsyncClient] | str | None = None,
                              lease: OperationLease | None = None
                              ) -> BindingSelection[AsyncClient]:
        rows = await self._peek_with_lease(target, axis=axis, query=query,
            max_nodes=max_nodes, scope=scope, lease=lease)
        try:
            return _navigation_selection(rows, at)
        except BaseException:
            await rows.aclose()
            raise

    async def execute(
        self, source: str, *, working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] | None = None,
        scope: ResourceScope[AsyncClient] | str | None = None,
    ) -> Any:
        """Evaluate the console's Lark expressions and return typed live values."""
        self._begin_value_operation()
        lease = OperationLease(self)
        try:
            if self._expression_lock is None:
                self._expression_lock = asyncio.Lock()
            async with self._expression_lock:
                adapter = _AsyncExpressionAdapter(self, lease, scope)
                runtime = _expression_runtime(self, adapter,
                                              working_directory, compile_arguments)
                runtime.client = adapter
                worker = asyncio.create_task(asyncio.to_thread(runtime.evaluate, source))
                try:
                    return await asyncio.shield(worker)
                except asyncio.CancelledError:
                    adapter.cancel()
                    await asyncio.gather(worker, return_exceptions=True)
                    await adapter.wait_callbacks()
                    raise
        finally:
            lease.close()
            self._end_value_operation()

    async def traverse_stream(self, target: MatchTarget | Path, **kwargs: Any
                              ) -> AsyncIterator[traverse_stream_pb2.TraverseStreamEvent]:
        """Yield preorder visits immediately; require completion and terminal OK.

        Visits are provisional until this iterator exhausts successfully. Close
        the iterator when stopping early to cancel native work promptly.
        """
        request = _traversal_value_request(self, target, **kwargs)
        async with aclosing(self._traverse_events(request)) as events:
            async for event in events:
                yield event

    async def _traverse_events(self, request: traverse_request_pb2.TraverseRequest
                              ) -> AsyncIterator[traverse_stream_pb2.TraverseStreamEvent]:
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        self._begin_value_operation()
        call = None
        count = 0
        completed = False
        consumed = False
        depths: list[int] = []
        try:
            call = analysis_service_pb2_grpc.AnalysisServiceStub(self._channel).StreamTraverse(
                self._compilation_request(request), timeout=self.config.rpc_timeout)
            async for event in call:
                kind = event.WhichOneof("event")
                if completed:
                    raise AnalysisError(grpc.StatusCode.DATA_LOSS, "traversal event follows completion")
                if kind == "node":
                    node = event.node
                    if node.index != count or node.depth > len(depths):
                        raise AnalysisError(grpc.StatusCode.DATA_LOSS, "invalid traversal ordinal or depth")
                    if node.depth == 0:
                        if node.HasField("parent_index"):
                            raise AnalysisError(grpc.StatusCode.DATA_LOSS, "traversal root has a parent")
                        depths.clear()
                    elif (not node.HasField("parent_index") or
                          node.parent_index != depths[node.depth - 1]):
                        raise AnalysisError(grpc.StatusCode.DATA_LOSS, "invalid traversal parent")
                    depths[node.depth:] = [count]
                    count += 1
                elif kind == "completed":
                    if event.completed.node_count != count:
                        raise AnalysisError(grpc.StatusCode.DATA_LOSS, "traversal completion count mismatch")
                    completed = True
                else:
                    raise AnalysisError(grpc.StatusCode.DATA_LOSS, "empty traversal event")
                yield event
            if not completed:
                raise AnalysisError(grpc.StatusCode.DATA_LOSS, "traversal stream ended without completion")
            status = call.code()
            if inspect.isawaitable(status):
                status = await status
            if status != grpc.StatusCode.OK:
                raise AnalysisError(status, "traversal stream did not finish successfully")
            consumed = True
        except grpc.aio.AioRpcError as error:
            raise AnalysisError(error.code(), error.details()) from error
        finally:
            if call is not None and not consumed and not call.done():
                call.cancel()
            self._end_value_operation()

    async def _stream_traverse_request(self, request: traverse_request_pb2.TraverseRequest,
                                      *, on_node: Callable[..., Any] | None = None
                                      ) -> traverse_stream_pb2.TraverseCompleted:
        completed = None
        async with aclosing(self._traverse_events(request)) as events:
            async for event in events:
                if event.WhichOneof("event") == "node":
                    if on_node is not None:
                        result = on_node(event.node)
                        if inspect.isawaitable(result):
                            await result
                else:
                    completed = event.completed
        assert completed is not None
        return completed

    async def stream_traverse(self, target: MatchTarget | Path, *,
                              on_node: Callable[..., Any], **kwargs: Any
                              ) -> traverse_stream_pb2.TraverseCompleted:
        """Consume each node with backpressure; return only completion metadata."""
        request = _traversal_value_request(self, target, **kwargs)
        return await self._stream_traverse_request(request, on_node=on_node)

    async def traverse(self, target: MatchTarget | Path, **kwargs: Any
                       ) -> traverse_response_pb2.TraverseResponse:
        """Explicit compatibility collector; use stream_traverse for bounded memory."""
        request = _traversal_value_request(self, target, **kwargs)
        return await self._collect_traverse_request(request)

    async def _collect_traverse_request(self, request: traverse_request_pb2.TraverseRequest
                                        ) -> traverse_response_pb2.TraverseResponse:
        response = traverse_response_pb2.TraverseResponse()
        completed = await self._stream_traverse_request(request,
            on_node=lambda node: response.nodes.add().CopyFrom(node))
        response.depth_limited = completed.depth_limited
        return response

    async def cfg_stream(self, target: MatchTarget | Path, function: str | None = None,
                         **kwargs: Any) -> AsyncIterator[cfg_stream_pb2.CfgStreamEvent]:
        """Yield provisional CFG events; exhaust for completion and terminal OK.

        Use aclosing when stopping early. Retained trees and bindings reuse the
        pinned AST; function must be omitted for an exact function binding.
        """
        request = _cfg_value_request(self, target, function, **kwargs)
        async with aclosing(self._cfg_events(request)) as events:
            async for event in events:
                yield event

    async def _cfg_events(self, request: cfg_request_pb2.CfgRequest
                          ) -> AsyncIterator[cfg_stream_pb2.CfgStreamEvent]:
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        self._begin_value_operation()
        call = None
        consumed = False
        state = CfgStreamState()
        try:
            call = analysis_service_pb2_grpc.AnalysisServiceStub(self._channel).StreamCfg(
                self._compilation_request(request), timeout=self.config.rpc_timeout)
            async for event in call:
                state.consume(event)
                yield event
            state.finish()
            status = call.code()
            if inspect.isawaitable(status):
                status = await status
            if status != grpc.StatusCode.OK:
                raise AnalysisError(status, "CFG stream did not finish successfully")
            consumed = True
        except grpc.aio.AioRpcError as error:
            raise AnalysisError(error.code(), error.details()) from error
        finally:
            if call is not None and not consumed and not call.done():
                call.cancel()
            self._end_value_operation()

    async def _stream_cfg_request(self, request: cfg_request_pb2.CfgRequest, *,
                                  on_event: Callable[..., Any]) -> cfg_stream_pb2.CfgCompleted:
        completed = None
        async with aclosing(self._cfg_events(request)) as events:
            async for event in events:
                result = on_event(event)
                if inspect.isawaitable(result):
                    await result
                if event.HasField("completed"):
                    completed = event.completed
        assert completed is not None
        return completed

    async def stream_cfg(self, target: MatchTarget | Path, function: str | None = None, *,
                         on_event: Callable[..., Any], **kwargs: Any) -> cfg_stream_pb2.CfgCompleted:
        """Consume events with backpressure and return completion counts."""
        request = _cfg_value_request(self, target, function, **kwargs)
        return await self._stream_cfg_request(request, on_event=on_event)

    async def cfg(self, path: MatchTarget | Path, function: str | None = None,
                  **kwargs: Any) -> cfg_response_pb2.CfgResponse:
        """Explicit collector; use cfg_stream or stream_cfg for bounded memory."""
        return await self._collect_cfg_request(_cfg_value_request(self, path, function, **kwargs))

    async def _collect_cfg_request(self, request: cfg_request_pb2.CfgRequest) -> cfg_response_pb2.CfgResponse:
        response = cfg_response_pb2.CfgResponse()
        def collect(event: cfg_stream_pb2.CfgStreamEvent) -> None:
            if event.HasField("graph_started"):
                response.graphs.add().CopyFrom(event.graph_started.graph)
            elif event.HasField("block"):
                graph = response.graphs[event.block.graph_index]
                graph.blocks.add().CopyFrom(event.block.block)
                graph.availability.extend(event.block.block.availability)
            elif event.HasField("graph_completed"):
                response.graphs[event.graph_completed.graph_index].is_complete = event.graph_completed.is_complete
        await self._stream_cfg_request(request, on_event=collect)
        return response

    async def variable_flow_stream(self, variable: BindingSelection, function: BindingSelection,
                                   **kwargs: Any) -> AsyncIterator[variable_flow_pb2.VariableFlowEvent]:
        """Yield usage sites and converged facts; exhaust for completion and terminal OK."""
        request = _variable_flow_request(self, variable, function, **kwargs)
        async with aclosing(self._variable_flow_events(request)) as events:
            async for event in events:
                yield event

    async def _variable_flow_events(self, request: variable_flow_pb2.VariableFlowRequest
                                    ) -> AsyncIterator[variable_flow_pb2.VariableFlowEvent]:
        self._ensure_stub()
        self._begin_value_operation()
        call = None
        consumed = False
        state = VariableFlowState(request.value_domain)
        try:
            call = analysis_service_pb2_grpc.AnalysisServiceStub(self._channel).StreamVariableFlow(
                request, timeout=self.config.rpc_timeout)
            async for event in call:
                state.consume(event)
                yield event
            state.finish()
            status = call.code()
            if inspect.isawaitable(status):
                status = await status
            if status != grpc.StatusCode.OK:
                raise AnalysisError(status, "variable flow stream did not finish successfully")
            consumed = True
        except grpc.aio.AioRpcError as error:
            raise AnalysisError(error.code(), error.details()) from error
        finally:
            if call is not None and not consumed and not call.done():
                call.cancel()
            self._end_value_operation()

    async def _stream_variable_flow_request(self, request: variable_flow_pb2.VariableFlowRequest, *,
                                             on_event: Callable[..., Any]) -> variable_flow_pb2.VariableFlowCompleted:
        completed = None
        async with aclosing(self._variable_flow_events(request)) as events:
            async for event in events:
                result = on_event(event)
                if inspect.isawaitable(result):
                    await result
                if event.HasField("completed"):
                    completed = event.completed
        if completed is None:
            raise AnalysisError(grpc.StatusCode.DATA_LOSS, "missing variable flow completion")
        return completed

    async def stream_variable_flow(self, variable: BindingSelection, function: BindingSelection,
                                   *, on_event: Callable[..., Any], **kwargs: Any) -> variable_flow_pb2.VariableFlowCompleted:
        return await self._stream_variable_flow_request(
            _variable_flow_request(self, variable, function, **kwargs), on_event=on_event)

    async def variable_flow(self, variable: BindingSelection, function: BindingSelection,
                            **kwargs: Any) -> variable_flow_pb2.VariableFlowReport:
        return await self._collect_variable_flow_request(_variable_flow_request(self, variable, function, **kwargs))

    async def _collect_variable_flow_request(self, request: variable_flow_pb2.VariableFlowRequest
                                             ) -> variable_flow_pb2.VariableFlowReport:
        report = variable_flow_pb2.VariableFlowReport()
        def collect(event: variable_flow_pb2.VariableFlowEvent) -> None:
            kind = event.WhichOneof("event")
            if kind == "started": report.analysis.CopyFrom(event.started)
            elif kind == "usage": report.usages.add().CopyFrom(event.usage)
            elif kind == "fact": report.facts.add().CopyFrom(event.fact)
            elif kind == "finding": report.findings.add().CopyFrom(event.finding)
            elif kind == "completed": report.completed.CopyFrom(event.completed)
        await self._stream_variable_flow_request(request, on_event=collect)
        return report

    async def run_script(
                         self, source: str, *,
                         path: str | Path | FileHandle[AsyncClient] | InputDescriptor | None = None,
                         working_directory: str | Path | None = None,
                         compile_arguments: Sequence[str] = (), max_steps: int | None = None,
                         profile: InputDescriptor | None = None,
                         scope: ResourceScope[AsyncClient] | str | None = None,
                         ) -> script_response_pb2.ScriptResponse:
        request = script_request(source, path=path, working_directory=working_directory,
            compile_arguments=compile_arguments, max_steps=max_steps, profile=profile)
        request.resource_scope_id = _scope_id(scope)
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        try:
            return await analysis_service_pb2_grpc.AnalysisServiceStub(self._channel).RunScript(
                self._compilation_request(request), timeout=self.config.rpc_timeout)
        except grpc.aio.AioRpcError as error:
            raise AnalysisError(error.code(), error.details()) from error

    async def start_batch(
        self,
        inputs: FileSet | Sequence[InputDescriptor],
        body_source: str,
        *,
        group_variable: str = "part",
        size: int | None = None,
        count: int | None = None,
        jobs: int | None = None,
        memory_bytes: int | None = None,
        continue_on_error: bool = False,
        request_id: str | None = None,
    ) -> BatchRun:
        """Start or recover an idempotent server-owned durable batch."""
        request = start_batch_request(
            inputs,
            body_source,
            group_variable=group_variable,
            size=size,
            count=count,
            jobs=jobs,
            memory_bytes=memory_bytes,
            continue_on_error=continue_on_error,
            request_id=request_id,
        )
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        try:
            result = await analysis_service_pb2_grpc.AnalysisServiceStub(self._channel).StartBatch(
                self._compilation_request(request), timeout=self.config.rpc_timeout
            )
            return batch_run(result)
        except grpc.aio.AioRpcError as error:
            raise AnalysisError(error.code(), error.details()) from error

    async def batch_status(self, run: BatchRun | str) -> BatchRun:
        """Fetch current durable status after a disconnect or client restart."""
        request = batch_pb2.BatchRunRequest(
            run_id=run.run_id if isinstance(run, BatchRun) else run
        )
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        try:
            result = await analysis_service_pb2_grpc.AnalysisServiceStub(self._channel).BatchStatus(
                request, timeout=self.config.rpc_timeout
            )
            return batch_run(result)
        except grpc.aio.AioRpcError as error:
            raise AnalysisError(error.code(), error.details()) from error

    async def _control_batch(
        self, method: str, run: BatchRun | str, expected_revision: int | None
    ) -> BatchRun:
        if isinstance(run, BatchRun):
            run_id = run.run_id
            revision = run.revision if expected_revision is None else expected_revision
        else:
            run_id = run
            if expected_revision is None:
                raise ValueError("expected_revision is required when a run id is used")
            revision = expected_revision
        request = batch_pb2.BatchControlRequest(
            run_id=run_id, expected_revision=revision
        )
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        try:
            result = await getattr(
                analysis_service_pb2_grpc.AnalysisServiceStub(self._channel), method
            )(request, timeout=self.config.rpc_timeout)
            return batch_run(result)
        except grpc.aio.AioRpcError as error:
            raise AnalysisError(error.code(), error.details()) from error

    async def cancel_batch(
        self, run: BatchRun | str, *, expected_revision: int | None = None
    ) -> BatchRun:
        return await self._control_batch("CancelBatch", run, expected_revision)

    async def resume_batch(
        self, run: BatchRun | str, *, expected_revision: int | None = None
    ) -> BatchRun:
        return await self._control_batch("ResumeBatch", run, expected_revision)

    async def retry_batch(
        self, run: BatchRun | str, *, expected_revision: int | None = None
    ) -> BatchRun:
        return await self._control_batch("RetryBatch", run, expected_revision)

    async def callgraph(self, target: MatchTarget | Path, function: str | None = None, *,
                        working_directory: str | Path | None = None,
                        compile_arguments: Sequence[str] = (), visit_implicit_code: bool | None = None,
                        visit_template_instantiations: bool | None = None,
                        max_nodes: int | Literal["all"] | None = None,
                        max_edges: int | None = None, max_call_sites: int | None = None,
                        direction: str | int | None = None,
                        max_depth: int | Literal["all"] | None = None,
                        projection: str = "shallow",
                        main_file_only: bool = False,
                        exclude_system_headers: bool = False,
                        node_filter: str | None = None,
                        strict_node_filter: bool = False, retain_nodes: bool = False,
                        payload_depth: int = 24,
                        payload_nodes: int = 10000,
                        scope: ResourceScope[AsyncClient] | str | None = None) -> call_graph_response_pb2.CallGraphResponse | CallGraph:
        request = _call_graph_value_request(self, target, function,
            working_directory=working_directory, compile_arguments=compile_arguments,
            visit_implicit_code=visit_implicit_code,
            visit_template_instantiations=visit_template_instantiations,
            max_nodes=max_nodes, max_edges=max_edges, max_call_sites=max_call_sites,
            direction=direction, max_depth=max_depth, projection=projection,
            main_file_only=main_file_only,
            exclude_system_headers=exclude_system_headers, node_filter=node_filter,
            strict_node_filter=strict_node_filter, retain_nodes=retain_nodes,
            payload_depth=payload_depth,
            payload_nodes=payload_nodes, scope=scope)
        response = await self._collect_call_graph_request(request)
        if retain_nodes:
            return CallGraph(response, owner=self._own_value(response.retained_nodes))
        return response

    async def callgraph_stream(
        self, target: MatchTarget | Path, function: str | None = None, **kwargs: Any,
    ) -> AsyncIterator[call_graph_stream_pb2.CallGraphStreamEvent]:
        """Yield graph events; exhaust the iterator to verify completion and status."""
        request = _call_graph_value_request(self, target, function, **kwargs)
        async with aclosing(self._call_graph_events(request)) as events:
            async for event in events:
                yield event

    async def stream_callgraph(
        self, target: MatchTarget | Path, function: str | None = None, *,
        on_event: Callable[..., Any], **kwargs: Any,
    ) -> call_graph_stream_pb2.CallGraphCompleted:
        """Consume call-graph events with backpressure and return terminal counts."""
        request = _call_graph_value_request(self, target, function, **kwargs)
        return await self._stream_call_graph_request(request, on_event=on_event)

    async def _stream_call_graph_request(
        self, request: call_graph_request_pb2.CallGraphRequest, *,
        on_event: Callable[..., Any],
    ) -> call_graph_stream_pb2.CallGraphCompleted:
        completed = None
        async with aclosing(self._call_graph_events(request)) as events:
            async for event in events:
                outcome = on_event(event)
                if inspect.isawaitable(outcome):
                    await outcome
                if event.HasField("completed"):
                    completed = event.completed
        assert completed is not None
        return completed

    async def _call_graph_events(
        self, request: call_graph_request_pb2.CallGraphRequest,
    ) -> AsyncIterator[call_graph_stream_pb2.CallGraphStreamEvent]:
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        self._begin_value_operation()
        call = None
        consumed = False
        retained_id = ""
        state = CallGraphStreamState(
            expect_unlimited_depth=request.unlimited_depth,
            expect_exclude_system_headers=request.exclude_system_headers,
            expect_node_filter=request.node_filter,
            expect_strict_node_filter=request.strict_node_filter,
        )
        try:
            call = analysis_service_pb2_grpc.AnalysisServiceStub(self._channel).StreamCallGraph(
                self._compilation_request(request), timeout=self.config.rpc_timeout)
            async for event in call:
                if event.HasField("completed") and event.completed.HasField("retained_nodes"):
                    retained_id = event.completed.retained_nodes.session_id
                state.consume(event)
                yield event
            status = call.code()
            if inspect.isawaitable(status):
                status = await status
            if status != grpc.StatusCode.OK:
                raise AnalysisError(status, "call-graph stream did not finish successfully")
            state.finish()
            consumed = True
        except grpc.aio.AioRpcError as error:
            raise AnalysisError(error.code(), error.details()) from error
        finally:
            if call is not None and not consumed and not call.done():
                call.cancel()
            if retained_id and not consumed:
                self._release_value(retained_id)
            self._end_value_operation()

    async def _collect_call_graph_request(
        self, request: call_graph_request_pb2.CallGraphRequest,
    ) -> call_graph_response_pb2.CallGraphResponse:
        response = call_graph_response_pb2.CallGraphResponse()
        received_event = False
        async def collect(event: call_graph_stream_pb2.CallGraphStreamEvent) -> None:
            nonlocal received_event
            received_event = True
            if event.HasField("graph_started"):
                response.CopyFrom(event.graph_started.graph)
                response.ClearField("availability")
            elif event.HasField("node"):
                record = event.node.node
                response.nodes.add().CopyFrom(record)
                _append_call_graph_availability(response, record)
            elif event.HasField("edge"):
                record = event.edge.edge
                response.edges.add().CopyFrom(record)
                _append_call_graph_availability(response, record)
            elif event.HasField("call_site"):
                record = event.call_site.call_site
                response.call_sites.add().CopyFrom(record)
                _append_call_graph_availability(response, record)
            elif event.HasField("completed"):
                response.is_complete = event.completed.is_complete
                if event.completed.HasField("retained_nodes"):
                    response.retained_nodes.CopyFrom(event.completed.retained_nodes)
        try:
            await self._stream_call_graph_request(request, on_event=collect)
        except AnalysisError as error:
            if (received_event or error.code != grpc.StatusCode.UNIMPLEMENTED
                    or request.WhichOneof("target") != "file"):
                raise
            self._ensure_stub()
            assert self._channel is not None and self.config is not None
            try:
                response = await analysis_service_pb2_grpc.AnalysisServiceStub(self._channel).CallGraph(
                    self._compilation_request(request), timeout=self.config.rpc_timeout)
            except grpc.aio.AioRpcError as unary_error:
                raise AnalysisError(unary_error.code(), unary_error.details()) from unary_error
            if request.unlimited_depth and not (
                response.HasField("selection_unlimited_depth")
                and response.selection_unlimited_depth
            ):
                raise AnalysisError(
                    grpc.StatusCode.FAILED_PRECONDITION,
                    "server did not confirm unlimited call-graph depth support",
                )
            if (response.exclude_system_headers != request.exclude_system_headers
                    or response.node_filter != request.node_filter
                    or response.strict_node_filter != request.strict_node_filter):
                raise AnalysisError(
                    grpc.StatusCode.FAILED_PRECONDITION,
                    "server did not confirm call-graph boundary filters",
                )
        if request.retain_nodes:
            retained = response.retained_nodes
            indices = [node.native_match_index for node in response.nodes
                       if not node.is_virtual_root and node.HasField("native_match_index")]
            expected = sum(not node.is_virtual_root for node in response.nodes)
            if (not retained.session_id or not retained.result_revision
                    or len(indices) != expected or len(set(indices)) != expected
                    or retained.row_count != expected
                    or any(index >= expected for index in indices)):
                if retained.session_id:
                    self._release_value(retained.session_id)
                raise AnalysisError(grpc.StatusCode.FAILED_PRECONDITION,
                                    "server did not return valid retained call-graph nodes")
        return response

    async def match_file(
        self, path: str | Path, query: MatcherInput, *,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        traversal_mode: int = match_service_pb2.MATCH_TRAVERSAL_MODE_AS_IS,
    ) -> match_service_pb2.MatchResponse:
        """Acquire a validated AST and create an independent result cursor."""
        return await self._cursor_match(file_request(
            path, query, working_directory=working_directory,
            compile_arguments=compile_arguments, traversal_mode=traversal_mode,
        ))

    async def continue_match(
        self, session_id: str, bind: str, query: MatcherInput, *,
        match_index: int | None = None,
        scope: int = match_result_pb2.BINDING_MATCH_SCOPE_SUBTREE,
        expected_result_revision: int | None = None,
        traversal_mode: int = match_service_pb2.MATCH_TRAVERSAL_MODE_AS_IS,
    ) -> match_service_pb2.MatchResponse:
        """Replace one cursor's result using roots in its latest revision."""
        return await self._cursor_match(retained_request(
            session_id, query, bind=bind, match_index=match_index, scope=scope,
            expected_result_revision=expected_result_revision, traversal_mode=traversal_mode,
        ))

    async def restart_match(
        self, session_id: str, query: MatcherInput, *, expected_result_revision: int | None = None,
        traversal_mode: int = match_service_pb2.MATCH_TRAVERSAL_MODE_AS_IS,
    ) -> match_service_pb2.MatchResponse:
        """Run again from the cursor's pinned translation-unit root."""
        return await self._cursor_match(retained_request(
            session_id, query, expected_result_revision=expected_result_revision,
            traversal_mode=traversal_mode,
        ))

    async def close_match(self, session_id: str) -> None:
        """Release a cursor; closing an unavailable valid UUID is idempotent."""
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        stub = match_service_pb2_grpc.MatchServiceStub(self._channel)
        try:
            await stub.CloseSession(match_service_pb2.CloseSessionRequest(session_id=session_id),
                                    timeout=self.config.rpc_timeout)
        except grpc.aio.AioRpcError as error:
            raise CursorError(error.code(), error.details()) from error
        reference = self._values.pop(session_id, None)
        owner = reference() if reference else None
        if owner is not None:
            owner.closed = True

    async def _management_call(self, method: str, request: Any) -> Any:
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        stub = match_service_pb2_grpc.MatchServiceStub(self._channel)
        try:
            return await getattr(stub, method)(request, timeout=self.config.rpc_timeout)
        except grpc.aio.AioRpcError as error:
            raise CursorError(error.code(), error.details()) from error

    async def _index_call(self, method: str, request: Any) -> Any:
        self._ensure_stub()
        assert self._channel is not None and self.config is not None
        stub = index_grpc.IndexServiceStub(self._channel)
        try:
            return await getattr(stub, method)(request, timeout=self.config.rpc_timeout)
        except grpc.aio.AioRpcError as error:
            raise CursorError(error.code(), error.details()) from error

    async def list_project_indexes(self) -> index_pb.ListProjectIndexesResponse:
        """List saved project indexes and current work on this server."""
        return await self._index_call("ListProjectIndexes", index_pb.ListProjectIndexesRequest())

    async def start_project_index(
        self, project_root: str | Path, *, compile_commands: str | Path = "",
        poll_interval_seconds: int = 2,
    ) -> index_pb.ProjectIndexStatus:
        """Enqueue background indexing; paths refer to the server filesystem."""
        if not 1 <= poll_interval_seconds <= 3600:
            raise ValueError("poll_interval_seconds must be between 1 and 3600")
        return await self._index_call("StartProjectIndex", index_pb.StartProjectIndexRequest(
            project_root=str(project_root), compile_commands=str(compile_commands),
            poll_interval_seconds=poll_interval_seconds))

    async def project_index_status(self, project_root: str | Path) -> index_pb.ProjectIndexStatus:
        """Probe progress without waiting for background work."""
        return await self._index_call("GetProjectIndexStatus", index_pb.ProjectIndexRequest(project_root=str(project_root)))

    async def pause_project_index(self, project_root: str | Path) -> index_pb.ProjectIndexStatus:
        return await self._index_call("PauseProjectIndex", index_pb.ProjectIndexRequest(project_root=str(project_root)))

    async def resume_project_index(self, project_root: str | Path) -> index_pb.ProjectIndexStatus:
        return await self._index_call("ResumeProjectIndex", index_pb.ProjectIndexRequest(project_root=str(project_root)))

    async def cancel_project_index(self, project_root: str | Path) -> index_pb.ProjectIndexStatus:
        return await self._index_call("CancelProjectIndex", index_pb.ProjectIndexRequest(project_root=str(project_root)))

    async def find_symbols(self, project_root: str | Path, query: str, *,
                           limit: int = 100, prefix: bool = False, kind: str = "", unique_symbols: bool = False,
                           source_only: bool = False, offset: int = 0, expected_revision: int = 0) -> index_pb.FindSymbolsResponse:
        """Find declarations/definitions without loading native ASTs."""
        if not 1 <= limit <= 1000:
            raise ValueError("limit must be between 1 and 1000")
        for name, value in (("offset", offset), ("expected_revision", expected_revision)):
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                raise ValueError(f"{name} must be a non-negative integer")
        kinds = {"": index_pb.FindSymbolsRequest.KIND_ANY,
                 "function": index_pb.FindSymbolsRequest.KIND_FUNCTION,
                 "class": index_pb.FindSymbolsRequest.KIND_CLASS,
                 "variable": index_pb.FindSymbolsRequest.KIND_VARIABLE, "alias": index_pb.FindSymbolsRequest.KIND_ALIAS}
        if kind not in kinds:
            raise ValueError("kind must be function, class, variable, alias, or empty")
        return await self._index_call("FindSymbols", index_pb.FindSymbolsRequest(
            project_root=str(project_root), query=query, limit=limit,
            kind=kinds[kind], unique_symbols=unique_symbols, match_mode=(index_pb.FindSymbolsRequest.MATCH_MODE_PREFIX if prefix
                        else index_pb.FindSymbolsRequest.MATCH_MODE_EXACT), source_only=source_only,
            offset=offset, expected_revision=expected_revision))

    async def lookup_symbol(self, project_root: str | Path, usr: str) -> index_pb.FindSymbolsResponse:
        return await self._index_call("LookupSymbol", index_pb.LookupSymbolRequest(
            project_root=str(project_root), usr=usr))

    async def server_status(self) -> match_service_pb2.ServerStatusResponse:
        """Read live process, retained cursor, memory cache and disk artifact usage."""
        return await self._management_call("ServerStatus", match_service_pb2.ServerStatusRequest())

    async def list_sessions(self) -> match_service_pb2.ListSessionsResponse:
        """List retained cursors visible to the transport's caller owner."""
        return await self._management_call("ListSessions", match_service_pb2.ListSessionsRequest())

    async def _session_info(self, session_id: str) -> match_service_pb2.SessionInfo:
        return await self._management_call("AttachSession", match_service_pb2.AttachSessionRequest(session_id=session_id))

    async def attach_session(self, session_id: str) -> ParsedTree[AsyncClient]:
        """Attach the latest cursor revision as a reusable tree and renew its TTL."""
        self._begin_value_operation()
        try:
            response = await self._session_info(session_id)
            return ParsedTree(
                response.file_path, self._own_value(response),
                _absolute_source_file(response.file_path),
            )
        finally:
            self._end_value_operation()

    async def prune_caches(self, *, memory: bool = True, disk: bool = False
                           ) -> match_service_pb2.PruneCachesResponse:
        """Prune reusable entries; active cursor pins and storage leases survive."""
        return await self._management_call("PruneCaches", match_service_pb2.PruneCachesRequest(memory=memory, disk=disk))

    def start_background_query(
        self,
        expression: MatcherInput,
        files: Sequence[str | Path] = (),
        *,
        on_event: EventCallback | None = None,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        on_error: Callable[[QueryError], Any] | None = None,
    ) -> "BackgroundQuery":
        """Start consuming immediately and return a retained task handle."""
        async def consume() -> list[QueryEvent]:
            try:
                return await self.query(
                    expression, files, on_event=on_event,
                    working_directory=working_directory,
                    compile_arguments=compile_arguments,
                )
            except QueryError as exc:
                if on_error is not None:
                    result = on_error(exc)
                    if inspect.isawaitable(result):
                        await result
                raise

        task = asyncio.create_task(consume(), name=f"ctk-query-{uuid.uuid4().hex[:8]}")
        self._background.add(task)
        task.add_done_callback(lambda done: done.exception() if not done.cancelled() else None)
        return BackgroundQuery(task)

    async def query_session(self) -> "QuerySession":
        """Open a serialized bidirectional interactive query session."""
        return await QuerySession.open(self)

    async def wait_background(self) -> list[list[QueryEvent]]:
        """Wait for every retained background stream to reach terminal status."""
        tasks = tuple(self._background)
        if not tasks:
            return []
        outcomes = await asyncio.gather(*tasks, return_exceptions=True)
        failures = [item for item in outcomes if isinstance(item, BaseException)]
        self._background.difference_update(tasks)
        if failures:
            raise failures[0]
        return [item for item in outcomes if isinstance(item, list)]

    async def aclose(self) -> None:
        current_loop = asyncio.get_running_loop()
        if self._loop is not None and current_loop is not self._loop:
            raise RuntimeError("AsyncClient must be closed from its owning event loop")
        self._value_closing = True
        if self._value_idle is not None:
            await self._value_idle.wait()
        if self._value_close_lock is None:
            self._value_close_lock = asyncio.Lock()
        async with self._value_close_lock:
            try:
                await self._close_resources()
            finally:
                self._value_closed = True

    async def _close_resources(self) -> None:
        errors: list[BaseException] = []
        owners = tuple(self._values.items())
        for _, reference in owners:
            owner = reference()
            if owner is not None:
                owner.closed = True
        try:
            if self._expression_runtime is not None:
                try:
                    self._expression_runtime.close()
                except BaseException as error:
                    errors.append(error)
                finally:
                    self._expression_runtime = None
            for task in tuple(self._background):
                if not task.done():
                    task.cancel()
            if self._background:
                try:
                    await asyncio.gather(*self._background, return_exceptions=True)
                except BaseException as error:
                    errors.append(error)
                self._background.clear()
            identifiers = tuple(set(self._values) | self._pending_value_cleanup)
            self._pending_value_cleanup.update(identifiers)
            outcomes = await asyncio.gather(
                *(self._close_value_cleanup(identifier) for identifier in identifiers),
                return_exceptions=True,
            )
            for identifier, outcome in zip(identifiers, outcomes):
                if isinstance(outcome, BaseException):
                    errors.append(outcome)
                else:
                    self._values.pop(identifier, None)
            for scope_id, scope in tuple(self._resource_scopes.items()):
                try:
                    await scope.arelease()
                except BaseException as error:
                    errors.append(error)
                else:
                    self._resource_scopes.pop(scope_id, None)
            for lease_id in tuple(self._file_leases):
                try:
                    await self.close_file(lease_id)
                except BaseException as error:
                    errors.append(error)
        finally:
            if self._channel is not None:
                try:
                    await self._channel.close()
                except BaseException as error:
                    errors.append(error)
            self._channel = None
            self._stub = None
            self._loop = None
        _raise_cleanup_errors(errors)

    async def __aenter__(self) -> "AsyncClient":
        self._ensure_stub()
        return self

    async def __aexit__(
        self, exc_type: object, exc: BaseException | None, tb: object
    ) -> None:
        try:
            await self.aclose()
        except BaseException as cleanup:
            _preserve_cleanup_error(exc, cleanup, "async client")


@dataclass
class BackgroundQuery:
    """A running background query whose task keeps the RPC stream consumed."""

    task: asyncio.Task[list[QueryEvent]]

    @property
    def done(self) -> bool:
        return self.task.done()

    async def result(self) -> list[QueryEvent]:
        return await self.task

    def cancel(self) -> bool:
        return self.task.cancel()


class QuerySession:
    """Bidirectional session with serialized command writes and live receives."""

    def __init__(self, client: AsyncClient) -> None:
        self.client = client
        self._commands: asyncio.Queue[query_pb2.QueryCommand | None] = asyncio.Queue()
        self._call: Any = None
        self._events: list[QueryEvent] = []
        self._reading = False
        self._input_closed = False
        self._matching_started = False
        self._closing = False

    @property
    def closing(self) -> bool:
        """Whether the client is intentionally shutting down this stream."""
        return self._closing

    @classmethod
    async def open(cls, client: AsyncClient) -> "QuerySession":
        instance = cls(client)
        stub = client._ensure_stub()
        assert client.config is not None
        async def commands() -> AsyncIterator[query_pb2.QueryCommand]:
            while True:
                command = await instance._commands.get()
                if command is None:
                    return
                yield command
        instance._call = stub.QuerySession(commands(), timeout=client.config.rpc_timeout)
        return instance

    def _send(self, command_name: str, value: Any = None) -> str:
        if self._input_closed:
            raise RuntimeError("query session is closed")
        if self._call is None or self._call.done():
            raise RuntimeError("query session stream has ended")
        command = query_pb2.QueryCommand(request_id=uuid.uuid4().hex)
        if value is None:
            getattr(command, command_name).SetInParent()
        else:
            getattr(command, command_name).CopyFrom(self.client._compilation_request(value))
        self._commands.put_nowait(command)
        return command.request_id

    async def start_query(self, query: MatcherInput) -> str:
        return self._send("start_query", query_pb2.StartQuery(query=matcher_query(query)))

    async def add_files(
        self, files: Sequence[str | Path], *, working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
    ) -> str:
        return self._send("add_files", query_pb2.AddFiles(files=_file_inputs(
            files, working_directory=working_directory, compile_arguments=compile_arguments
        )))

    async def match(self) -> str:
        self._matching_started = True
        return self._send("match")

    async def pause(self) -> str:
        return self._send("pause")

    async def resume(self) -> str:
        return self._send("resume")

    async def events(self) -> AsyncIterator[QueryEvent]:
        """Read response events until half-close or server completion."""
        consumed = False
        completed = False
        self._reading = True
        try:
            async for event in self._call:
                self._events.append(event)
                completed = completed or event.WhichOneof("event") == "completed"
                yield event
            if not completed:
                raise QueryError("query session ended without Completed", partial_events=self._events)
            consumed = True
        except grpc.aio.AioRpcError as exc:
            raise QueryError(
                f"query session failed: {exc.code().name}: {exc.details()}",
                partial_events=self._events,
                rejected=_rejection_from_status(exc),
            ) from exc
        except asyncio.CancelledError as exc:
            if asyncio.current_task() and asyncio.current_task().cancelling():
                raise
            raise QueryError("query session cancelled: CANCELLED", partial_events=self._events) from exc
        finally:
            self._reading = False
            if not consumed and not self._call.done():
                self._call.cancel()
                self._commands.put_nowait(None)

    async def half_close(self) -> None:
        if not self._input_closed:
            self._input_closed = True
            self._commands.put_nowait(None)

    async def cancel(self) -> None:
        self._closing = True
        self._call.cancel()
        if not self._input_closed:
            self._input_closed = True
            self._commands.put_nowait(None)

    async def aclose(self) -> None:
        self._closing = True
        if self._call is not None and not self._call.done():
            if not self._matching_started:
                await self.cancel()
            else:
                await self.half_close()
                if self._reading:
                    await self._call.code()
                else:
                    async for _ in self.events():
                        pass

    async def __aenter__(self) -> "QuerySession":
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()


@dataclass
class Client:
    """Synchronous compatibility facade used by the existing REPL runtime."""

    address: str | None = None
    config_path: str | Path | None = None
    config: NetworkConfig | None = None
    compilation_database: str | Path | None = None
    _resolved_config: NetworkConfig | None = field(default=None, init=False, repr=False)
    _async_client: AsyncClient | None = field(default=None, init=False, repr=False)
    _async_loop: asyncio.AbstractEventLoop | None = field(default=None, init=False, repr=False)
    _query_session: QuerySession | None = field(default=None, init=False, repr=False)
    _last_session_command: str | None = field(default=None, init=False, repr=False)
    _last_session_command_request_id: str | None = field(default=None, init=False, repr=False)
    _background_handles: dict[str, BackgroundQuery] = field(default_factory=dict, init=False, repr=False)
    _values: dict[str, weakref.ReferenceType[CursorOwner[Client]]] = field(
        default_factory=dict, init=False, repr=False)
    _pending_value_cleanup: set[str] = field(default_factory=set, init=False, repr=False)
    _file_leases: set[str] = field(default_factory=set, init=False, repr=False)
    _resource_scopes: dict[str, ResourceScope[Client]] = field(default_factory=dict, init=False, repr=False)
    _expression_runtime: Any = field(default=None, init=False, repr=False)

    def _configuration(self) -> NetworkConfig:
        if self._resolved_config is None:
            self._resolved_config = (load_network_config(self.config_path)
                if self.config_path is not None else self.config or load_network_config())
            self.config = self._resolved_config
        return self._resolved_config

    def server_version(self) -> VersionInfo:
        """Return the connected server binary's build identity."""
        return self._cursor_call("server_version")

    def _own_value(self, response: Any) -> CursorOwner[Client]:
        current = self._values.get(response.session_id)
        existing = current() if current else None
        if existing is not None and not existing.closed and existing.revision == response.result_revision:
            return existing
        holder: list[Any] = [None]
        def release(session_id: str) -> None:
            if self._values.get(session_id) is holder[0]:
                self._release_value(session_id)
        owner = CursorOwner(cast(Client, self), response.session_id, response.result_revision,
                             release)
        holder[0] = self._values[response.session_id] = weakref.ref(owner)
        return owner

    def _release_value(self, session_id: str) -> None:
        self._values.pop(session_id, None)
        self._pending_value_cleanup.add(session_id)
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            try:
                self._close_value_cleanup(session_id)
            except Exception:
                # Finalizers cannot propagate failures; retain the identifier
                # so the next explicit operation or close retries cleanup.
                pass

    def _flush_value_cleanup(self) -> None:
        errors: list[BaseException] = []
        for identifier in tuple(self._pending_value_cleanup):
            try:
                self.close_match(identifier)
            except Exception as error:
                errors.append(error)
            else:
                self._pending_value_cleanup.remove(identifier)
        _raise_cleanup_errors(errors)

    def _close_value_cleanup(self, identifier: str) -> None:
        if identifier not in self._pending_value_cleanup:
            return
        self.close_match(identifier)
        self._pending_value_cleanup.discard(identifier)

    def parse(self, path: str | Path | InputDescriptor, *, working_directory: str | Path | None = None,
              compile_arguments: Sequence[str] = (), compilation_database: str | Path | None = None,
              scope: ResourceScope[Client] | str | None = None) -> ParsedTree[Client]:
        """Parse a file and retain a tree with automatic native ownership."""
        response = self._cursor_call("_parse_response", path,
            working_directory=working_directory, compile_arguments=compile_arguments,
            compilation_database=compilation_database, scope=scope)
        return ParsedTree(
            str(path), self._own_value(response),
            _absolute_source_file(path, working_directory),
        )

    def parse_cpp(
        self, code: str, *, file: str | Path | None = None,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        compilation_database: str | Path | None = None,
        includes: Sequence[str] = (), translation_unit: bool = False,
        scope: ResourceScope[Client] | str | None = None,
    ) -> ParsedTree[Client]:
        """Parse temporary C++ statements or a complete translation unit.

        Borrow compilation settings from ``file``, or the first available
        compilation database entry when omitted. Explicit flags append overrides.
        """
        response = self._cursor_call(
            "_parse_cpp_response", code, file=file,
            working_directory=working_directory, compile_arguments=compile_arguments,
            compilation_database=compilation_database, includes=includes,
            translation_unit=translation_unit, scope=scope,
        )
        return ParsedTree(response.source_file, self._own_value(response), response.source_file)

    def match_in(
        self, query: MatcherInput, target: MatchTarget, *,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        traversal_mode: int = match_service_pb2.MATCH_TRAVERSAL_MODE_AS_IS,
        on_row: MatchRowCallback | None = None,
        scope: ResourceScope[Client] | str | None = None,
    ) -> MatchValue[Client]:
        if isinstance(target, CallGraphNodeValue):
            target = target.binding
        callback: AsyncMatchRowCallback | None = None
        if on_row is not None:
            async def checked_callback(row: match_result_pb2.MatchResult) -> None:
                await _invoke_sync_callback(on_row, row)

            callback = checked_callback

        request = _value_request(self, query, target,
            working_directory=working_directory, compile_arguments=compile_arguments,
            traversal_mode=traversal_mode, scope=scope)
        source_id = target._owner.session_id if isinstance(
            target, (ParsedTree, MatchValue, BindingSelection)
        ) else None
        completion, store = self._cursor_call(
            "_stream_cursor_match", request, on_row=callback,
            source_session_id=source_id,
        )
        return MatchValue[Client]._from_store(
            store, self._own_value(completion),
            source_file=_absolute_source_file(target, working_directory),
        )

    def peek(self, target: BindingSelection, *, axis: str = "children",
             query: MatcherInput | None = None, max_nodes: int = 0,
             on_row: MatchRowCallback | None = None,
             scope: ResourceScope[Client] | str | None = None
             ) -> MatchValue[Client]:
        """Inspect direct neighbours without changing the starting reference."""
        request = _navigation_request(self, target, axis, query, max_nodes, scope)
        callback = None
        if on_row is not None:
            async def callback(row: match_result_pb2.MatchResult) -> None:
                await _invoke_sync_callback(on_row, row)
        completion, store = self._cursor_call(
            "_stream_cursor_match", request, on_row=callback,
            source_session_id=target._owner.session_id)
        return MatchValue._from_store(store, self._own_value(completion),
                                      source_file=target.source_file)

    def step(self, target: BindingSelection, *, axis: str = "children",
             query: MatcherInput | None = None, at: int | None = None,
             max_nodes: int = 0,
             scope: ResourceScope[Client] | str | None = None
             ) -> BindingSelection[Client]:
        """Return a selected neighbour as a reusable native reference."""
        rows = self.peek(target, axis=axis, query=query,
                         max_nodes=max_nodes, scope=scope)
        try:
            return _navigation_selection(rows, at)
        except BaseException:
            rows.close()
            raise

    def close(self) -> None:
        """Release every high-level retained value owned by this client."""
        errors: list[BaseException] = []
        for identifier, reference in tuple(self._values.items()):
            owner = reference()
            if owner is not None:
                owner.closed = True
            self._pending_value_cleanup.add(identifier)
        self._values.clear()
        if self._expression_runtime is not None:
            try:
                self._expression_runtime.close()
            except Exception as error:
                errors.append(error)
            finally:
                self._expression_runtime = None
        try:
            self._flush_value_cleanup()
        except Exception as error:
            errors.append(error)
        for scope_id, scope in tuple(self._resource_scopes.items()):
            try:
                scope.release()
            except Exception as error:
                errors.append(error)
            else:
                self._resource_scopes.pop(scope_id, None)
        for lease_id in tuple(self._file_leases):
            try:
                self.close_file(lease_id)
            except Exception as error:
                errors.append(error)
        _raise_cleanup_errors(errors)

    def execute(
        self, source: str, *, working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] | None = None,
    ) -> Any:
        """Evaluate expressions/blocks, returning reusable typed values."""
        runtime = _expression_runtime(self, self, working_directory, compile_arguments)
        return runtime.evaluate(source)

    def __enter__(self) -> Client:
        self._configuration()
        return self

    def __exit__(self, exc_type: object, exc: BaseException | None, tb: object) -> None:
        try:
            self.close()
        except BaseException as cleanup:
            _preserve_cleanup_error(exc, cleanup, "client")

    def _cursor_call(self, method: str, *args: Any, **kwargs: Any) -> Any:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            pass
        else:
            raise RuntimeError("synchronous cursor methods cannot run inside an active event loop")

        config = self._configuration()

        async def run() -> Any:
            async with AsyncClient(self.address, config=config, compilation_database=self.compilation_database) as client:
                return await getattr(client, method)(*args, **kwargs)
        return asyncio.run(run())

    def _cursor_call_keep_resource(self, method: str, *args: Any, **kwargs: Any) -> Any:
        """Call once while transferring a newly returned lease/scope to this facade."""
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            pass
        else:
            raise RuntimeError("synchronous cursor methods cannot run inside an active event loop")
        config = self._configuration()

        async def run() -> Any:
            async with AsyncClient(self.address, config=config,
                                   compilation_database=self.compilation_database) as client:
                result = await getattr(client, method)(*args, **kwargs)
                if isinstance(result, FileHandle):
                    client._file_leases.discard(result.lease_id)
                elif isinstance(result, ResourceScope):
                    client._resource_scopes.pop(result.resource_scope_id, None)
                return result
        return asyncio.run(run())

    def match_file(self, path: str | Path, query: MatcherInput, **kwargs: Any) -> match_service_pb2.MatchResponse:
        return self._cursor_call("match_file", path, query, **kwargs)

    def continue_match(self, session_id: str, bind: str, query: MatcherInput, **kwargs: Any) -> match_service_pb2.MatchResponse:
        return self._cursor_call("continue_match", session_id, bind, query, **kwargs)

    def restart_match(self, session_id: str, query: MatcherInput, **kwargs: Any) -> match_service_pb2.MatchResponse:
        return self._cursor_call("restart_match", session_id, query, **kwargs)

    def close_match(self, session_id: str) -> None:
        self._cursor_call("close_match", session_id)
        reference = self._values.pop(session_id, None)
        owner = reference() if reference else None
        if owner is not None:
            owner.closed = True

    def discover_files(self, paths: Sequence[str | Path] = (), **kwargs: Any) -> FileSet:
        return self._cursor_call("discover_files", paths, **kwargs)

    def open_file(self, value: str | Path | InputDescriptor, **kwargs: Any) -> FileHandle[Client]:
        handle = self._cursor_call_keep_resource("open_file", value, **kwargs)
        result = FileHandle(handle.lease_id, handle.input, self,
                            handle.source_revision, handle.snapshot_id, handle.state)
        if kwargs.get("scope") is None:
            self._file_leases.add(result.lease_id)
        return result

    def list_files(self) -> tuple[Any, ...]:
        return self._cursor_call("list_files")

    def file_info(self, handle: FileHandle[Client] | ParsedTree[Client]) -> Any:
        return self._cursor_call("file_info", handle)

    def close_file(self, handle: FileHandle[Client] | ParsedTree[Client] | str) -> Any:
        response = self._cursor_call("close_file", handle)
        if isinstance(handle, FileHandle | str):
            self._file_leases.discard(handle.lease_id if isinstance(handle, FileHandle) else handle)
        return response

    def close_all_files(self) -> Any:
        response = self._cursor_call("close_all_files")
        self._file_leases.clear()
        return response

    def refresh_file(self, handle: FileHandle[Client] | ParsedTree[Client], **kwargs: Any) -> FileHandle[Client]:
        updated = self._cursor_call_keep_resource("refresh_file", handle, **kwargs)
        if kwargs.get("scope") is None:
            self._file_leases.add(updated.lease_id)
        return FileHandle(updated.lease_id, updated.input, self,
                          updated.source_revision, updated.snapshot_id, updated.state)

    def open_resource_scope(self, **kwargs: Any) -> ResourceScope[Client]:
        scope = self._cursor_call_keep_resource("open_resource_scope", **kwargs)
        scope._client = self
        self._resource_scopes[scope.resource_scope_id] = scope
        return scope

    def describe_resource_scope(self, scope: ResourceScope[Client] | str) -> Any:
        return self._cursor_call("describe_resource_scope", scope)

    def cancel_resource_scope(self, scope: ResourceScope[Client] | str) -> Any:
        return self._cursor_call("cancel_resource_scope", scope)

    def release_resource_scope(self, scope: ResourceScope[Client] | str) -> Any:
        info = self._cursor_call("release_resource_scope", scope)
        if info.cleanup_acknowledged:
            self._resource_scopes.pop(_scope_id(scope), None)
        return info

    def resource_status(self) -> Any:
        return self._cursor_call("resource_status")

    def list_project_indexes(self) -> index_pb.ListProjectIndexesResponse:
        """List saved project indexes and current work on this server."""
        return self._cursor_call("list_project_indexes")

    def start_project_index(self, project_root: str | Path, *,
                            compile_commands: str | Path = "",
                            poll_interval_seconds: int = 2) -> index_pb.ProjectIndexStatus:
        return self._cursor_call("start_project_index", project_root,
                                 compile_commands=compile_commands,
                                 poll_interval_seconds=poll_interval_seconds)

    def project_index_status(self, project_root: str | Path) -> index_pb.ProjectIndexStatus:
        return self._cursor_call("project_index_status", project_root)

    def pause_project_index(self, project_root: str | Path) -> index_pb.ProjectIndexStatus:
        return self._cursor_call("pause_project_index", project_root)

    def resume_project_index(self, project_root: str | Path) -> index_pb.ProjectIndexStatus:
        return self._cursor_call("resume_project_index", project_root)

    def cancel_project_index(self, project_root: str | Path) -> index_pb.ProjectIndexStatus:
        return self._cursor_call("cancel_project_index", project_root)

    def find_symbols(self, project_root: str | Path, query: str, *,
                     limit: int = 100, prefix: bool = False, kind: str = "", unique_symbols: bool = False,
                     source_only: bool = False, offset: int = 0, expected_revision: int = 0) -> index_pb.FindSymbolsResponse:
        return self._cursor_call("find_symbols", project_root, query, limit=limit, prefix=prefix, kind=kind,
                                 unique_symbols=unique_symbols, source_only=source_only, offset=offset,
                                 expected_revision=expected_revision)

    def lookup_symbol(self, project_root: str | Path, usr: str) -> index_pb.FindSymbolsResponse:
        return self._cursor_call("lookup_symbol", project_root, usr)

    def server_status(self) -> match_service_pb2.ServerStatusResponse:
        return self._cursor_call("server_status")

    def list_sessions(self) -> match_service_pb2.ListSessionsResponse:
        return self._cursor_call("list_sessions")

    def attach_session(self, session_id: str) -> ParsedTree[Client]:
        response = self._cursor_call("_session_info", session_id)
        return ParsedTree(response.file_path, self._own_value(response))

    def prune_caches(self, *, memory: bool = True, disk: bool = False
                     ) -> match_service_pb2.PruneCachesResponse:
        return self._cursor_call("prune_caches", memory=memory, disk=disk)

    def stream_traverse(self, target: MatchTarget | Path, *,
                        on_node: Callable[..., None], **kwargs: Any
                        ) -> traverse_stream_pb2.TraverseCompleted:
        """Deliver visits one at a time without retaining their payloads."""
        request = _traversal_value_request(self, target, **kwargs)
        async def callback(node: Any) -> None:
            await _invoke_sync_callback(on_node, node)
        return self._cursor_call("_stream_traverse_request", request, on_node=callback)

    def traverse(self, target: MatchTarget | Path, **kwargs: Any
                 ) -> traverse_response_pb2.TraverseResponse:
        """Compatibility collector; stream_traverse emits nodes before completion."""
        request = _traversal_value_request(self, target, **kwargs)
        return self._cursor_call("_collect_traverse_request", request)

    def bind_async_client(self, client: AsyncClient) -> None:
        """Attach the active CLI loop for commands submitted by worker threads."""
        self._async_client = client
        self._async_loop = asyncio.get_running_loop()
        config = getattr(client, "config", None)
        if self.config_path is None and config is not None:
            self.config = self._resolved_config = config
        else:
            self._configuration()

    def bind_query_session(self, session: QuerySession) -> None:
        self._query_session = session

    def send_session_command(
        self, command: str, value: str | None = None, *,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
    ) -> str:
        if self._query_session is None or self._async_loop is None:
            raise QueryError("interactive query session is unavailable; restart the console")
        if self._query_session._input_closed:
            raise QueryError("interactive query session is closed")

        async def send() -> Any:
            self._query_session.client.compilation_database = self.compilation_database
            if command == "start":
                return await self._query_session.start_query(value or "")
            elif command == "add":
                return await self._query_session.add_files(
                    [value or ""], working_directory=working_directory,
                    compile_arguments=compile_arguments,
                )
            elif command == "match":
                return await self._query_session.match()
            elif command == "pause":
                return await self._query_session.pause()
            elif command == "resume":
                return await self._query_session.resume()
            elif command == "close":
                return await self._query_session.half_close()
            raise QueryError(f"unsupported interactive query session command: {command}")

        try:
            running_loop = asyncio.get_running_loop()
        except RuntimeError:
            running_loop = None
        if running_loop is self._async_loop:
            raise QueryError("interactive query session command cannot run on its event loop")
        if self._async_loop.is_closed() or not self._async_loop.is_running():
            raise QueryError("interactive query session is unavailable because its event loop has stopped")
        try:
            future = asyncio.run_coroutine_threadsafe(send(), self._async_loop)
            request_id = future.result()
            self._last_session_command = command
            self._last_session_command_request_id = request_id
        except QueryError:
            raise
        except Exception as exc:
            raise QueryError(f"interactive query session {command} failed: {exc}") from exc
        return f"session {command} command sent"

    def start_background_query(
        self,
        expression: MatcherInput,
        files: Sequence[str | Path] = (),
        *,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
    ) -> str:
        """Schedule an interactive query while the CLI continues prompting."""
        if self._async_client is None or self._async_loop is None:
            raise RuntimeError("background query requires the interactive async client")
        query_id = uuid.uuid4().hex[:8]
        ready: concurrent.futures.Future[BackgroundQuery] = concurrent.futures.Future()

        def start() -> None:
            try:
                handle = self._async_client.start_background_query(
                    expression, files, on_event=lambda event: print(_format_event(event)),
                    working_directory=working_directory,
                    compile_arguments=compile_arguments,
                    on_error=lambda error: print(f"error: {error}"),
                )
                self._background_handles[query_id] = handle
                ready.set_result(handle)
            except BaseException as exc:
                ready.set_exception(exc)

        self._async_loop.call_soon_threadsafe(start)
        ready.result(timeout=2)
        return f"background query {query_id} started"

    @overload
    def match(
        self, matcher: MatcherInput, *, file: str | Path,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
    ) -> MatchValue[Client]: ...

    @overload
    def match(
        self, matcher: MatcherInput, *, files: Sequence[str | Path] | None = None,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (), file: None = None,
    ) -> list[str]: ...

    def match(
        self, matcher: MatcherInput, *, files: Sequence[str | Path] | None = None,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        file: str | Path | None = None,
    ) -> list[str] | MatchValue[Client]:
        """Run a query synchronously; bindings are returned as JSON rows."""
        if file is not None:
            if files is not None:
                raise ValueError("use either file or files, not both")
            return self.match_in(matcher, file, working_directory=working_directory,
                                 compile_arguments=compile_arguments)
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            pass
        else:
            raise RuntimeError("Client.match cannot run inside an active event loop")

        config = self._configuration()

        async def run() -> list[str]:
            async with AsyncClient(self.address, config=config, compilation_database=self.compilation_database) as client:
                events = await client.query(
                    matcher, files or (), working_directory=working_directory,
                    compile_arguments=compile_arguments,
                )
            rows: list[str] = []
            for event in events:
                if event.WhichOneof("event") != "match":
                    continue
                values = {
                    name: {
                        "kind": binding.kind,
                        "name": binding.name,
                        "type": binding.type,
                    }
                    for name, binding in event.match.bindings.items()
                }
                rows.append(json.dumps(values, sort_keys=True))
            return rows

        return asyncio.run(run())

    def cfg(
            self, function: str | BindingSelection, *,
            path: MatchTarget | Path | None = None,
            **kwargs: Any) -> cfg_response_pb2.CfgResponse:
        request = _cfg_value_request(self, function if path is None else path,
                                     None if path is None else function, **kwargs)
        return self._cursor_call("_collect_cfg_request", request)

    def stream_cfg(self, function: str | BindingSelection, *, path: MatchTarget | Path | None = None,
                   on_event: Callable[..., Any], **kwargs: Any) -> cfg_stream_pb2.CfgCompleted:
        request = _cfg_value_request(self, function if path is None else path,
                                     None if path is None else function, **kwargs)
        async def callback(event: Any) -> None:
            await _invoke_sync_callback(on_event, event)
        return self._cursor_call("_stream_cfg_request", request, on_event=callback)

    def variable_flow(self, variable: BindingSelection, function: BindingSelection,
                      **kwargs: Any) -> variable_flow_pb2.VariableFlowReport:
        return self._cursor_call("_collect_variable_flow_request", _variable_flow_request(self, variable, function, **kwargs))

    def stream_variable_flow(self, variable: BindingSelection, function: BindingSelection,
                            *, on_event: Callable[..., Any], **kwargs: Any) -> variable_flow_pb2.VariableFlowCompleted:
        async def callback(event: variable_flow_pb2.VariableFlowEvent) -> None:
            await _invoke_sync_callback(on_event, event)
        return self._cursor_call("_stream_variable_flow_request", _variable_flow_request(self, variable, function, **kwargs), on_event=callback)

    def run_script(
                   self, source: str, *,
                   path: str | Path | FileHandle[Client] | InputDescriptor | None = None,
                   working_directory: str | Path | None = None,
                   compile_arguments: Sequence[str] = (),
                   max_steps: int | None = None,
                   profile: InputDescriptor | None = None,
                   scope: ResourceScope[Client] | str | None = None) -> script_response_pb2.ScriptResponse:
        return self._cursor_call("run_script", source, path=path,
            working_directory=working_directory, compile_arguments=compile_arguments,
            max_steps=max_steps, profile=profile, scope=scope)

    def start_batch(
        self,
        inputs: FileSet | Sequence[InputDescriptor],
        body_source: str,
        **kwargs: Any,
    ) -> BatchRun:
        """Start an idempotent server-owned durable batch."""
        return self._cursor_call("start_batch", inputs, body_source, **kwargs)

    def batch_status(self, run: BatchRun | str) -> BatchRun:
        return self._cursor_call("batch_status", run)

    def cancel_batch(
        self, run: BatchRun | str, *, expected_revision: int | None = None
    ) -> BatchRun:
        return self._cursor_call(
            "cancel_batch", run, expected_revision=expected_revision
        )

    def resume_batch(
        self, run: BatchRun | str, *, expected_revision: int | None = None
    ) -> BatchRun:
        return self._cursor_call(
            "resume_batch", run, expected_revision=expected_revision
        )

    def retry_batch(
        self, run: BatchRun | str, *, expected_revision: int | None = None
    ) -> BatchRun:
        return self._cursor_call(
            "retry_batch", run, expected_revision=expected_revision
        )

    def callgraph(
                  self, target: MatchTarget | Path, function: str | None = None,
                  **kwargs: Any) -> call_graph_response_pb2.CallGraphResponse | CallGraph:
        request = _call_graph_value_request(self, target, function, **kwargs)
        response = self._cursor_call("_collect_call_graph_request", request)
        if request.retain_nodes:
            return CallGraph(response, selector=self.callgraph,
                             owner=self._own_value(response.retained_nodes))
        return response

    def stream_callgraph(self, target: MatchTarget | Path, function: str | None = None,
                         *, on_event: Callable[..., Any], **kwargs: Any
                         ) -> call_graph_stream_pb2.CallGraphCompleted:
        request = _call_graph_value_request(self, target, function, **kwargs)
        async def callback(event: Any) -> None:
            await _invoke_sync_callback(on_event, event)
        return self._cursor_call("_stream_call_graph_request", request, on_event=callback)


def _raise_cleanup_errors(errors: Sequence[BaseException]) -> None:
    if len(errors) == 1:
        raise errors[0]
    if errors:
        raise BaseExceptionGroup("client resource cleanup failed", list(errors))


class _AsyncExpressionAdapter:
    """Run the shared synchronous evaluator with calls on its owner's loop."""

    def __init__(self, client: AsyncClient, lease: OperationLease,
                 scope: ResourceScope[AsyncClient] | str | None = None) -> None:
        self.client = client
        self.lease = lease
        self.scope = scope
        self._cancelled = False
        self._futures: set[concurrent.futures.Future[Any]] = set()
        self._future_lock = Lock()
        self._row_callbacks: set[asyncio.Task[Any]] = set()

    def cancel(self) -> None:
        with self._future_lock:
            self._cancelled = True
            futures = tuple(self._futures)
        for future in futures:
            future.cancel()

    async def wait_callbacks(self) -> None:
        """Join cancelled row callbacks before releasing runtime scopes."""
        if self._row_callbacks:
            await asyncio.gather(*tuple(self._row_callbacks), return_exceptions=True)

    def _call(self, method: str, *args: Any, **kwargs: Any) -> Any:
        with self._future_lock:
            if self._cancelled:
                raise asyncio.CancelledError
            future = asyncio.run_coroutine_threadsafe(
                getattr(self.client, method)(*args, **kwargs), self.client._loop)
            self._futures.add(future)
        try:
            return future.result()
        finally:
            with self._future_lock:
                self._futures.discard(future)

    @property
    def compilation_database(self) -> str | Path | None:
        return self.client.compilation_database

    @compilation_database.setter
    def compilation_database(self, value: str | Path | None) -> None:
        self.client.compilation_database = value

    def parse(self, path: str | Path, *, working_directory: str | Path | None = None,
              compile_arguments: Sequence[str] = ()) -> ParsedTree[AsyncClient]:
        return self._call("_parse_with_lease", path,
            working_directory=working_directory, compile_arguments=compile_arguments,
            lease=self.lease, scope=self.scope)

    def parse_cpp(
        self, code: str, *, file: str | Path | None = None,
        working_directory: str | Path | None = None,
        compile_arguments: Sequence[str] = (),
        compilation_database: str | Path | None = None,
        includes: Sequence[str] = (), translation_unit: bool = False,
        scope: ResourceScope[AsyncClient] | str | None = None,
    ) -> ParsedTree[AsyncClient]:
        return self._call(
            "_parse_cpp_with_lease", code, file=file,
            working_directory=working_directory, compile_arguments=compile_arguments,
            compilation_database=compilation_database, includes=includes,
            translation_unit=translation_unit, lease=self.lease,
            scope=self.scope if scope is None else scope,
        )

    def match_in(self, query: MatcherInput, target: MatchTarget, *,
                 working_directory: str | Path | None = None,
                 compile_arguments: Sequence[str] = (),
                 traversal_mode: match_service_pb2.MatchTraversalMode = match_service_pb2.MATCH_TRAVERSAL_MODE_AS_IS,
                 on_row: MatchRowCallback | None = None,
                 ) -> MatchValue[AsyncClient]:
        async def callback(row: match_result_pb2.MatchResult) -> None:
            assert on_row is not None
            task = asyncio.current_task()
            assert task is not None
            self._row_callbacks.add(task)
            try:
                await _invoke_sync_callback(on_row, row)
            finally:
                self._row_callbacks.discard(task)

        return self._call("_match_in_with_lease", query, target,
            working_directory=working_directory, compile_arguments=compile_arguments,
            traversal_mode=traversal_mode, on_row=callback if on_row is not None else None,
            lease=self.lease, scope=self.scope)

    def peek(self, target: BindingSelection, *, on_row: MatchRowCallback | None = None,
             **kwargs: Any) -> MatchValue[AsyncClient]:
        async def callback(row: match_result_pb2.MatchResult) -> None:
            assert on_row is not None
            task = asyncio.current_task()
            assert task is not None
            self._row_callbacks.add(task)
            try:
                await _invoke_sync_callback(on_row, row)
            finally:
                self._row_callbacks.discard(task)
        kwargs.setdefault("scope", self.scope)
        return self._call("_peek_with_lease", target, **kwargs,
                          on_row=callback if on_row else None,
                          lease=self.lease)

    def step(self, target: BindingSelection, **kwargs: Any) -> BindingSelection[AsyncClient]:
        kwargs.setdefault("scope", self.scope)
        return self._call("_step_with_lease", target, **kwargs,
                          lease=self.lease)

    def stream_traverse(self, target: MatchTarget | Path, *, on_node: Callable[..., None],
                        **kwargs: Any) -> traverse_stream_pb2.TraverseCompleted:
        async def callback(node: Any) -> None:
            task = asyncio.current_task()
            self._row_callbacks.add(task)
            try:
                await _invoke_sync_callback(on_node, node)
            finally:
                self._row_callbacks.discard(task)
        return self._call("stream_traverse", target, on_node=callback, **kwargs)

    def traverse(self, target: MatchTarget | Path, **kwargs: Any) -> traverse_response_pb2.TraverseResponse:
        return self._call("traverse", target, **kwargs)

    def cfg(self, function: str | BindingSelection, *, path: MatchTarget | Path | None = None,
            **kwargs: Any) -> cfg_response_pb2.CfgResponse:
        return self._call("cfg", function if path is None else path,
                          None if path is None else function, **kwargs)

    def variable_flow(self, variable: BindingSelection, function: BindingSelection, **kwargs: Any
                      ) -> variable_flow_pb2.VariableFlowReport:
        return self._call("variable_flow", variable, function, **kwargs)

    def stream_variable_flow(self, variable: BindingSelection, function: BindingSelection,
                             *, on_event: Callable[..., Any], **kwargs: Any) -> variable_flow_pb2.VariableFlowCompleted:
        async def callback(event: variable_flow_pb2.VariableFlowEvent) -> None:
            task = asyncio.current_task()
            self._row_callbacks.add(task)
            try:
                await _invoke_sync_callback(on_event, event)
            finally:
                self._row_callbacks.discard(task)
        return self._call("stream_variable_flow", variable, function, on_event=callback, **kwargs)

    def stream_cfg(self, function: str | BindingSelection, *, path: MatchTarget | Path | None = None,
                   on_event: Callable[..., Any], **kwargs: Any) -> cfg_stream_pb2.CfgCompleted:
        async def callback(event: Any) -> None:
            task = asyncio.current_task()
            self._row_callbacks.add(task)
            try:
                await _invoke_sync_callback(on_event, event)
            finally:
                self._row_callbacks.discard(task)
        return self._call("stream_cfg", function if path is None else path,
                          None if path is None else function, on_event=callback, **kwargs)

    def callgraph(self, target: MatchTarget | Path, function: str | None = None,
                  **kwargs: Any) -> call_graph_response_pb2.CallGraphResponse | CallGraph:
        value = self._call("callgraph", target, function, **kwargs)
        if isinstance(value, CallGraph):
            value._selector = self.callgraph
        return value

    def stream_callgraph(self, target: MatchTarget | Path, function: str | None = None,
                         *, on_event: Callable[..., Any], **kwargs: Any
                         ) -> call_graph_stream_pb2.CallGraphCompleted:
        async def callback(event: Any) -> None:
            task = asyncio.current_task()
            self._row_callbacks.add(task)
            try:
                await _invoke_sync_callback(on_event, event)
            finally:
                self._row_callbacks.discard(task)
        return self._call("stream_callgraph", target, function, on_event=callback, **kwargs)

    def match(self, query: MatcherInput, *, files: Sequence[str] | None = None,
              **kwargs: Any) -> list[Any]:
        return self._call("match", query, files or (), **kwargs)


def _expression_runtime(owner: Client | AsyncClient, adapter: Any,
                        working_directory: str | Path | None,
                        compile_arguments: Sequence[str] | None) -> Any:
    from clang_toolkit.cli.runtime.evaluator import Runtime
    if owner._expression_runtime is None:
        owner._expression_runtime = Runtime(adapter, cwd=Path(working_directory)
                                            if working_directory is not None else None)
    runtime = owner._expression_runtime
    if working_directory is not None and Path(working_directory).resolve() != runtime.cwd:
        raise ValueError("expression execution uses one working directory per client")
    if compile_arguments is not None:
        runtime.config_store.effective["extra_args"] = list(compile_arguments)
    return runtime


def _variable_flow_request(client: Client | AsyncClient, variable: BindingSelection,
                           function: BindingSelection, *, scope: ResourceScope[Any] | str | None = None,
                           max_blocks: int = 10000, max_events: int = 10000,
                           max_iterations: int = 100000,
                           value_domain: str | None = None) -> variable_flow_pb2.VariableFlowRequest:
    if not isinstance(variable, BindingSelection) or not isinstance(function, BindingSelection):
        raise MatchValueError("variable flow requires retained variable and function bindings")
    if value_domain not in (None, "interval"):
        raise ValueError("value_domain must be 'interval' or None")
    values = {}
    for name, value, limit in [("max_blocks", max_blocks, 100000), ("max_events", max_events, 100000),
                               ("max_iterations", max_iterations, 1000000)]:
        if type(value) is not int or not 1 <= value <= limit:
            raise ValueError(f"{name} must be 1..{limit}")
        values[name] = value
    var = _value_request(client, "decl()", variable, scope=scope)
    func = _value_request(client, "decl()", function, scope=scope)
    return variable_flow_pb2.VariableFlowRequest(variable=var.binding, function=func.binding,
                                                 resource_scope_id=var.resource_scope_id,
                                                 value_domain=variable_flow_pb2.INTERVAL if value_domain else 0,
                                                 **values)


def _cfg_value_request(client: Client | AsyncClient, target: MatchTarget | Path,
                       function: str | None = None, *,
                       scope: ResourceScope[Any] | str | None = None,
                       working_directory: str | Path | None = None,
                       compile_arguments: Sequence[str] = (), **kwargs: Any
                       ) -> cfg_request_pb2.CfgRequest:
    selected = _value_request(client, "decl()", target,
        working_directory=working_directory, compile_arguments=compile_arguments, scope=scope)
    if selected.HasField("binding"):
        if function is not None:
            raise ValueError("omit function name for an exact CFG binding")
    elif not isinstance(function, str) or not function:
        raise ValueError("CFG requires a function name and path=... or a retained tree")
    request = cfg_request("unused", function or "unused", **kwargs)
    if function is None:
        request.ClearField("function")
    request.ClearField("file")
    kind = selected.WhichOneof("target")
    getattr(request, kind).CopyFrom(getattr(selected, kind))
    request.resource_scope_id = selected.resource_scope_id
    return request


def _append_call_graph_availability(response: Any, record: Any) -> None:
    """Aggregate per-record coverage in the same order as the unary response."""
    for availability in getattr(record, "availability", ()):
        response.availability.add().CopyFrom(availability)


def _call_graph_value_request(
    client: Client | AsyncClient, target: MatchTarget | Path,
    function: str | None = None, *,
    working_directory: str | Path | None = None,
    compile_arguments: Sequence[str] = (),
    visit_implicit_code: bool | None = None,
    visit_template_instantiations: bool | None = None,
    max_nodes: int | Literal["all"] | None = None,
    max_edges: int | None = None,
    max_call_sites: int | None = None,
    direction: str | int | None = None,
    max_depth: int | Literal["all"] | None = None,
    projection: str = "shallow",
    main_file_only: bool = False,
    exclude_system_headers: bool = False,
    node_filter: str | None = None,
    strict_node_filter: bool = False,
    retain_nodes: bool = False,
    payload_depth: int = 24,
    payload_nodes: int = 10000,
    scope: ResourceScope[Any] | str | None = None,
) -> call_graph_request_pb2.CallGraphRequest:
    if isinstance(target, CallGraphNodeValue):
        target = target.binding
    if type(retain_nodes) is not bool:
        raise ValueError("retain_nodes must be boolean")
    if function is not None and (not isinstance(function, str) or not function):
        raise ValueError("function must be a non-empty string")
    if isinstance(target, BindingSelection) and function is not None:
        raise ValueError("omit function when using an exact retained binding")
    exact_call_site = (
        isinstance(target, BindingSelection)
        and target._binding_data is not None
        and target.value.HasField("call_site")
    )
    if exact_call_site and direction is not None:
        raise ValueError("direction and depth apply to callable targets, not call expressions")
    if exact_call_site and max_depth is not None:
        raise ValueError("depth applies to callable targets, not call expressions")
    if max_call_sites is not None and (type(max_call_sites) is not int or not 1 <= max_call_sites <= 1000000):
        raise ValueError("max_call_sites must be 1..1000000")
    unlimited_depth = max_depth == "all"
    if max_depth is not None and not unlimited_depth and (
        type(max_depth) is not int or not 0 <= max_depth <= 32
    ):
        raise ValueError("max_depth must be 0..32")
    directions = {
        "out": call_graph_request_pb2.CALL_GRAPH_DIRECTION_OUT,
        "in": call_graph_request_pb2.CALL_GRAPH_DIRECTION_IN,
        "both": call_graph_request_pb2.CALL_GRAPH_DIRECTION_BOTH,
    }
    if isinstance(direction, str):
        if direction not in directions:
            raise ValueError("direction must be in, out or both")
        direction_value = directions[direction]
    elif direction is None:
        direction_value = None
    elif type(direction) is int and direction in directions.values():
        direction_value = direction
    else:
        raise ValueError("direction must be in, out or both")

    if isinstance(target, str | Path | InputDescriptor):
        path, descriptor = _analysis_input(target)
        request = call_graph_request(path, working_directory=working_directory,
            compile_arguments=compile_arguments, visit_implicit_code=visit_implicit_code,
            visit_template_instantiations=visit_template_instantiations, max_nodes=max_nodes,
            max_edges=max_edges, projection=projection, main_file_only=main_file_only,
            exclude_system_headers=exclude_system_headers, node_filter=node_filter,
            strict_node_filter=strict_node_filter,
            payload_depth=payload_depth, payload_nodes=payload_nodes)
        if descriptor is not None:
            _apply_input_descriptor(request.file, descriptor)
    else:
        selected = _value_request(client, "decl()", target,
            working_directory=working_directory, compile_arguments=compile_arguments,
            scope=scope)
        request = call_graph_request("unused", visit_implicit_code=visit_implicit_code,
            visit_template_instantiations=visit_template_instantiations,
            max_nodes=max_nodes, max_edges=max_edges, projection=projection,
            main_file_only=main_file_only,
            exclude_system_headers=exclude_system_headers, node_filter=node_filter,
            strict_node_filter=strict_node_filter,
            payload_depth=payload_depth,
            payload_nodes=payload_nodes)
        request.ClearField("file")
        kind = selected.WhichOneof("target")
        if kind is None:
            raise MatchValueError("callgraph target has no retained selector")
        getattr(request, kind).CopyFrom(getattr(selected, kind))
        request.resource_scope_id = selected.resource_scope_id

    if function is not None:
        request.function = function
    if max_call_sites is not None:
        request.max_call_sites = max_call_sites
    if direction_value is not None:
        request.direction = direction_value
    if function is not None:
        if direction_value is None:
            request.direction = call_graph_request_pb2.CALL_GRAPH_DIRECTION_OUT
        if unlimited_depth:
            request.unlimited_depth = True
        else:
            request.max_depth = 1 if max_depth is None else max_depth
    elif max_depth is not None:
        if unlimited_depth:
            request.unlimited_depth = True
        else:
            request.max_depth = max_depth
    if scope is not None:
        request.resource_scope_id = _scope_id(scope)
    request.retain_nodes = retain_nodes
    return request


def _traversal_value_request(client: Client | AsyncClient, target: MatchTarget | Path,
                             *, scope: ResourceScope[Any] | str | None = None,
                             working_directory: str | Path | None = None,
                             compile_arguments: Sequence[str] = (), **kwargs: Any
                             ) -> traverse_request_pb2.TraverseRequest:
    selected = _value_request(client, "decl()", target,
        working_directory=working_directory, compile_arguments=compile_arguments,
        scope=scope)
    # Reuse validation of visitor options without acquiring or reparsing a tree.
    request = traversal_request("unused", **kwargs)
    request.ClearField("file")
    kind = selected.WhichOneof("target")
    getattr(request, kind).CopyFrom(getattr(selected, kind))
    request.resource_scope_id = selected.resource_scope_id
    return request


def _navigation_request(client: Client | AsyncClient, target: BindingSelection,
                        axis: str, query: MatcherInput | None, max_nodes: int,
                        scope: ResourceScope[Any] | str | None) -> match_service_pb2.MatchRequest:
    if not isinstance(target, BindingSelection):
        raise MatchValueError("navigation requires a retained native binding")
    axes = {"children": match_service_pb2.NAVIGATION_AXIS_CHILDREN,
            "parents": match_service_pb2.NAVIGATION_AXIS_PARENTS}
    if axis not in axes:
        raise ValueError("navigation axis must be children or parents")
    if type(max_nodes) is not int or not 0 <= max_nodes < (1 << 64):
        raise ValueError("navigation max_nodes must be a nonnegative uint64 integer")
    request = _value_request(client, query if query is not None else "decl()",
                             target, scope=scope)
    if query is None:
        request.ClearField("query")
    request.navigation_axis = axes[axis]
    request.navigation_max_nodes = max_nodes
    return request


def _navigation_selection(rows: MatchValue, at: int | None) -> BindingSelection:
    if at is not None and (type(at) is not int or at < 0):
        raise MatchValueError("navigation index must be a zero-based integer")
    if not len(rows):
        raise MatchValueError("navigation found no candidates")
    if at is None and len(rows) != 1:
        raise MatchValueError(
            f"navigation is ambiguous: {len(rows)} candidates; use at INDEX")
    index = 0 if at is None else at
    if index >= len(rows):
        raise MatchValueError("navigation index is outside the candidate list")
    return rows[index].binding("target")


def _value_request(
    client: Client | AsyncClient, query: MatcherInput, target: MatchTarget | Path, *,
    working_directory: str | Path | None = None,
    compile_arguments: Sequence[str] = (),
    traversal_mode: int = match_service_pb2.MATCH_TRAVERSAL_MODE_AS_IS,
    scope: ResourceScope[Any] | str | None = None,
) -> match_service_pb2.MatchRequest:
    if isinstance(target, CallGraphNodeValue):
        target = target.binding
    if isinstance(target, str | Path | InputDescriptor):
        target_path = target.path if isinstance(target, InputDescriptor) else target
        request = file_request(target_path, query, working_directory=working_directory,
                            compile_arguments=compile_arguments,
                            traversal_mode=traversal_mode)
        if isinstance(target, InputDescriptor):
            request.file.expected_profile_id = target.profile_id
            request.file.working_directory = target.working_directory or request.file.working_directory
            request.file.compile_arguments[:] = target.compile_arguments
            request.file.compilation_database = target.compilation_database
            request.file.frozen_profile = target.frozen_profile
    elif isinstance(target, FileHandle):
        if target._client is not client:
            raise MatchValueError("file handle belongs to a different client")
        request = match_service_pb2.MatchRequest(
            query=matcher_query(query), traversal_mode=traversal_mode,
            file_handle=resources_pb2.FileHandleTarget(lease_id=target.lease_id),
        )
    elif isinstance(target, ParsedTree | MatchValue | BindingSelection):
        target._owner.check(client)
        options: dict[str, Any] = {}
        if isinstance(target, BindingSelection):
            options.update(bind=target.name, match_index=target._index, scope=target.scope)
        request = retained_request(target._owner.session_id, query,
            expected_result_revision=target._owner.revision,
            traversal_mode=traversal_mode, **options)
        request.preserve_source = True
    else:
        raise TypeError("match target must be a path, descriptor, file handle, parsed tree or binding selection")
    request.resource_scope_id = _scope_id(scope)
    return request


def _absolute_source_file(
    target: MatchTarget | str | Path, working_directory: str | Path | None = None,
) -> str | None:
    if isinstance(target, str | Path):
        source = target
    elif isinstance(target, InputDescriptor):
        source = target.path
    elif isinstance(target, FileHandle):
        source = target.path
    elif isinstance(target, ParsedTree):
        source = target.source_file or target.path
    else:
        source = target.source_file
    if source is None:
        return None
    path = Path(source).expanduser()
    if not path.is_absolute():
        base = Path(working_directory).expanduser() if working_directory is not None else Path.cwd()
        path = base / path
    return str(path.resolve())


def _scope_id(scope: ResourceScope[Any] | str | None) -> str:
    return scope.resource_scope_id if isinstance(scope, ResourceScope) else (scope or "")


def _file_handle(client: Any, info: Any) -> FileHandle[Any]:
    if not info.lease_id or not info.HasField("input"):
        raise CursorError(grpc.StatusCode.DATA_LOSS, "file lease reply is missing its identity")
    return FileHandle(
        info.lease_id,
        InputDescriptor.from_proto(info.input),
        client,
        info.source_revision,
        info.snapshot_id,
        info.state,
    )


def _analysis_input(
    value: str | Path | FileHandle[Any] | InputDescriptor,
) -> tuple[str | Path, InputDescriptor | None]:
    if isinstance(value, FileHandle):
        return value.path, value.input
    if isinstance(value, InputDescriptor):
        return value.path, value
    return value, None


def _apply_input_descriptor(target: Any, descriptor: InputDescriptor | None) -> None:
    if descriptor is None:
        return
    target.expected_profile_id = descriptor.profile_id
    target.compile_arguments[:] = descriptor.compile_arguments
    target.working_directory = descriptor.working_directory
    target.compilation_database = descriptor.compilation_database
    target.frozen_profile = descriptor.frozen_profile


def _format_event(event: QueryEvent) -> str:
    kind = event.WhichOneof("event")
    if kind == "progress":
        return f"[{event.request_id}] {event.progress.file}: {event.progress.completed_files}/{event.progress.accepted_files} files"
    if kind == "match":
        values = {
            key: {"kind": value.kind, "name": value.name, "type": value.type}
            for key, value in event.match.bindings.items()
        }
        return f"[{event.request_id}] {json.dumps(values, sort_keys=True)}"
    if kind == "completed":
        return f"[{event.request_id}] completed: {event.completed.match_count} matches"
    if kind == "rejected":
        message = f"[{event.request_id}] rejected: {event.rejected.message}"
        if event.rejected.violations:
            message += "; " + "; ".join(
                _format_violation(item) for item in event.rejected.violations
            )
        return message
    return f"[{event.request_id}] {kind}"
